#Script Author: Voltron
#Noted Bugs: None that I can find, but it's always better to have planet in same sec as 0 class port
#Future Plans: Fix the fact u cant start with max shields. I was just lazy 

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Max Shield Buyer for Planets 1.0 " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Buys shields and dumps to planet till max'd."
echo ANSI_10 "*Date Made: " ANSI_13 "12/8/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Command prompt"
echo ANSI_10 "*Special Notes: " ANSI_13 "Can't start with your ship shields max'd. It can do multi hops to 0 class, but its better to twarp planet to 0 class.*"


cutText CURRENTLINE $location 1 7
IF ($location <> "Command")
        clientMessage "This script must be run from the Command menu"
        halt
END

getInput $PlanetNum "Enter Planet Number:"
getInput $Sector "Enter sector of planet, or S for same sector as 0 class port:"

IF ($Sector = "S") OR ($Sector = "s")
     goto :Sub_ShieldBuy
END
#getInput $0class "Enter sector to buy shields from (0 class port):"
setVar $0class 7804
setVar $1stTime 1

setTextTrigger NoStop :StopPrompt "Stop in this sector"
setTextTrigger Mines :Mines "Mined Sector:"

:Sub_ShieldBuy
#Get Current Sector
send "d"
waitFor "Command [TL="
getWord CURRENTLINE $cursec 2
stripText $cursec "[TL=00:00:00]:["
stripText $cursec "]"

IF ($cursec = $0class)
     send "PT"
     goto :Arrived
ELSEIF ($Sector = "S") OR ($Sector = "s")
     setVar $0class $cursec
     goto :Arrived
ELSE
     send $0Class "*"
     setTextTrigger ewarp :ewarp "Engage the Autopilot?"
     setTextTrigger twarp :twarp "engage the TransWarp drive?"

     pause
END

:twarp
send "NE"
goto :Arrived

:ewarp
send "E"
goto :Arrived

:Arrived
waitFor "Command [TL="
send "PT"
setTextLineTrigger buyShield :buyShield "C  Shield"
pause
:buyShield
getWord CURRENTLINE $canBuy 9
IF ($canBuy > 0)
     send "c" $canBuy "*"
ELSEIF ($canbuy = 0) AND ($1stTime = 0)
     echo ANSI_10 "**All out of money*"
     halt
END
send "Q"
setVar $1stTime 0
IF ($Sector = "S") OR ($Sector = "s")
     goto :Arrived2
END
send $Sector "*"
killAllTriggers
setTextTrigger ewarp2 :ewarp2 "Engage the Autopilot?"
setTextTrigger twarp2 :twarp2 "engage the TransWarp drive?"
setTextTrigger NoStop :StopPrompt "Stop in this sector"
setTextTrigger Mines :Mines "Mined Sector:"
pause

:twarp2
send "NE"
killTrigger ewarp2
goto :Arrived2
pause

:ewarp2
send "E"
killTrigger twarp2
goto :Arrived2
pause

:Arrived2
waitFor "Command [TL="
send "L" $PlanetNum "*"
setTextTrigger CurPShields :CurPShields "Planetary Defense Shielding Power Level ="
pause

:CurPShields
getWord CURRENTLINE $CurPShields 8

#Enter Cit and get to Shield Gen prompt
send "CGT"
killAllTriggers
waitFor "Citadel command"
setTextTrigger curshields :CurShields "You have "
pause
:CurShields
getWord CURRENTLINE $CurShields 3
divide $CurShields 10
send $CurShields "*"
setTextTrigger maxpshields :MaxPShields "The planet is limited to"
setTextTrigger shieldsuccess :ShieldSuccess "Citadel command"
pause

:MaxPShields
killAllTriggers
getWord CURRENTLINE $MaxPShields 6
subtract $MaxPShields $CurPShields
send "GT" $MaxPShields "*"
waitFor "Citadel command"
send "QQ"
echo ANSI_10 "**Planet Shields are max'd now"
halt

:ShieldSuccess
send "QQ"
goto :Sub_ShieldBuy

:StopPrompt
send "*"
killTrigger NoStop
setTextTrigger NoStop :StopPrompt "Stop in this sector"
pause

:Mines
send "*"
killTrigger Mines
setTextTrigger Mines :Mines "Mined Sector:"
pause
