#Script Author: Voltron
#Noted Bugs: None
#Future Plans: Maybe add support for dupes needing differnt login names/pw's, but its very low on priority list

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Login Mod 1.0 " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Same as Xide's login, except it deletes all msg's. Handy for unlimited games"
echo ANSI_10 "*Date Made: " ANSI_13 "10/6/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Anywhere"
echo ANSI_10 "*Special Notes: " ANSI_13 "Modified version of Xide's from script pack 1*"

setEventTrigger 0 :End "Connection lost"

waitfor "(ENTER for none):"
send LoginName "*"
waitfor "Trade Wars 2002 Game Server"
send Game
waitfor "module now loading."
send "*t***" Password "*"
waitfor "Password?"
setTextLineTrigger 1 :End "Sector  : "
setTextTrigger 2 :Pause "[Pause]"
setTextTrigger 3 :Pause "Do you wish to clear some avoids?"
pause

:Pause
getWord CURRENTLINE $temp 3
if ($temp = "Delete")
        send "Y"
end
send "*"
killTrigger 2
setTextTrigger 2 :Pause "[Pause]"
pause

:End
