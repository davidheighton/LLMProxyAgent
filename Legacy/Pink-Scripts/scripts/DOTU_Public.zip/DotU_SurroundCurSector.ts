#Script Author: NZThorDM
#Noted Bugs: One way warps screw it up. Wont enter sec's with enemy figs
#Future Plans: Fix 1 way warp issue. Make all surrounding sectors your figs. Maybe make it just throw 1 fig T instead of asking for input.

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Surround Sector " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Surrounds current sector with predetermined # of figs, and state, and mines"
echo ANSI_10 "*Date Made: " ANSI_13 "11/7/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Command prompt"
echo ANSI_10 "*Special Notes: " ANSI_13 "1 way warps screw it up. Mainly for offline traders or aliens*"

setvar $secinfo 0
setvar $sectest 0
setvar $cnt 1
setvar $next :loop

# Input for what will be placed in sector's
getinput $figs "**How many fighters to place in each sector? " 100
getinput $figstatus "What status should fighters have? (D, O, T) " D
getinput $mines "How many Armid mines to place? " 0

# get the current sector
send "d"
setTextLineTrigger 1 :getSectorNumber "Sector  : "
pause

:getSectorNumber
getWord CURRENTLINE $sector1 3
setVar $cursec $sector1
killtrigger 1

getSector $cursec $secinfo

setvar $waps $secinfo.warps

:loop

setvar $warpto $secinfo.warp[$cnt]

# check for previous figs in sec before moving...
getSector $warpto $sectest

if ($sectest.figs.quantity = 0)
        goto :chkbeacon
else
        goto :chkowner
end

# check owner of figs present, make sure its safe to enter sec
:chkowner
if ($sectest.figs.owner = "belong to your Corp")
        goto :chkbeacon
else
        goto :incloop
end

# check for fedspace beacon.
:chkbeacon
if ($sectest.beacon = "")
        goto :move
else
        goto :incloop
end

:move
# Place figs, mines and make them corp
send "m" $warpto "*"
send "f" $figs "*c" $figstatus "*"
if ($mines = 0)
        goto :cont
else
        send "h1" $mines "*c"
end

:cont
send "m" $cursec "*"

:incloop
# increase loop
if ($cnt <> $waps)
        add $cnt 1
        setvar $next :loop
else
        setvar $next :done
end

goto $next

pause

:done

echo "*Done*"

halt