#Script Author: Voltron
#Noted Bugs: Sometimes records wrong sectors
#Future Plans: Clean up code and document better for others. Add customizable increment so not so easily trappable

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Seek Out 2.0" ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "This is a brute force explore script. Goes sec by sec incremently. Dumps info to Seek Out Info.txt in TWX root directory"
echo ANSI_10 "*Date Made: " ANSI_13 "12/19/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Command prompt"
echo ANSI_10 "*Special Notes: " ANSI_13 "Wont record dupe planets in same sector. Be very careful with this one. Wont stop unless u stop script. Easily trappable. Sometimes gets stuck when figs are more then preset maxfigs*"

# check if we can run it from here
cutText CURRENTLINE $location 1 7

if ($location <> "Command")
        clientMessage "This script must be run from the game command menu"
        halt
end

:RecordAlienInput
Echo ANSI_12 "*Do you want to record aliens and unmanned ships as well? (Y/N)*"
GetConsoleInput $choice SINGLEKEY
IF ($choice = "Y") OR ($choice = "y")
        setVar $RecordAliens "Y"
ELSEIF ($choice = "N") or ($choice = "n")
        setVar $RecordAliens "N"
ELSE
        goto :RecordAlienInput
END
getInput $TotalFigs "Enter Max Figs in a sector to avoid"
getinput $StartSector "Enter sector to start in" 1
setVar $sector $StartSector
getTime $time
getDate $date
mergeText GAMENAME " - " $file
mergeText $file "Seek Out Report.txt" $file
write $file "Seek Out started on " & $date & " at " & $time

window WinSeekOut 175 75 "Enemy Search" onTop
setWindowContents WinSeekOut "Time Started: " & $time & "*Start Sector: " & $StartSector & "*Headin To: " & $sector

setVar $line CURRENTLINE
stripText $line "[TL=00:00:00]:[]"
getWord $line $CurSector 2

send "M" $StartSector "*E"
setTextTrigger 1 :NoAvoid "Mined Sector:"
setTextTrigger 2 :TollFig "vs."
setTextTrigger 3 :NoStop "Stop in this sector"
setTextTrigger 4 :MoveSector "Command [TL="
setTextTrigger 6 :FoundPlanet "Planets :"
setTextTrigger 7 :FoundTrader "Federals:"
setTextTrigger 8 :CurSector "Auto Warping"
setTextTrigger 9 :NoClearAvoids "Clear Avoids?"
setTextTrigger 10 :NoClearAvoids "DANGER! You have marked sector"
setTextTrigger 11 :FoundTrader ", w/"
pause

:NoAvoid
waitFor "(Y/N)"
send "*"
killTrigger 1
setTextTrigger 1 :NoAvoid "Mined Sector:"
pause

:TollFig
setVar $line CURRENTLINE
getWord $line $enemyfigs 6
stripText $enemyfigs ","
waitFor "Option?"
if ($enemyfigs <= $TotalFigs)
        send "A9999*"
        waitFor "You destroyed all the fighters."
else
        getTime $time
        getDate $date
        setVar $file ""
        mergeText GAMENAME " - " $file
        mergeText $file "Seek Out Report.txt" $file
        write $file $date & " " & $time & " - Fig Warning: " & $CurSector
        send "R"
        goto :MoveSector
end
killTrigger 2
setTextTrigger 2 :TollFig "vs."
pause

:NoStop
waitFor "[N]"
send "*"
killTrigger 3
setTextTrigger 3 :NoStop "Stop in this sector"
pause

:FoundTrader
getWord CURRENTLINE $alien 1
IF ($alien <> "Traders") OR ($alien <> "Federals:")
        goto :FoundShip
END
setVar $trader CURRENTLINE
stripText $trader "Traders : "
stripText $trader "Federals: "
getTime $time
getDate $date
setVar $file ""
mergeText GAMENAME " - " $file
mergeText $file "Seek Out Report.txt" $file
write $file $date & " " & $time & " - Trader - " & $trader & " - " & $CurSector
killTrigger 7
setTextTrigger 7 :FoundTrader "Federals:"
pause

:FoundPlanet
setVar $planet CURRENTLINE
IF ($planet = "Planets : (M) Terra")
        killTrigger 6
        setTextTrigger 6 :FoundPlanet "Planets :"
ELSE
        stripText $planet "Planets :"
        getTime $time
        getDate $date
        setVar $i 1
        goSub :SearchDupePlanet
        setVar $file ""
        mergeText GAMENAME " - " $file
        mergeText $file "Seek Out Report.txt" $file
        write $file $date & " " & $time & " - Planet - " & $planet & " - " & $CurSector
        killTrigger 6
        setTextTrigger 6 :FoundPlanet "Planets :"
END
pause

:FoundShip
IF ($RecordAliens = "Y")
        setVar $ship CURRENTLINE
        getTime $time
        getDate $date
        setVar $file ""
        mergeText GAMENAME " - " $file
        mergeText $file "Seek Out Report.txt" $file
        write $file $date & " " & $time & " - Ship - " & $ship & " - " & $CurSector
END
killTrigger 11
setTextTrigger 11 :FoundShip ", w/"
pause

:CurSector
setVar $line CURRENTLINE
getWord $line $CurSector 5
killTrigger 8
setTextTrigger 8 :CurSector "Auto Warping"
pause

:MoveSector
add $sector 1
setWindowContents WinSeekOut "Time Started: " & $time & "*Start Sector: " & $StartSector & "*Headin To: " & $sector
send "M" $sector "*"
waitFor "Engage the Autopilot?"
send "E"
killTrigger 4
setTextTrigger 4 :MoveSector "Command [TL="
pause

:NoClearAvoids
send "N"
getTime $time
getDate $date
setVar $file ""
mergeText GAMENAME " - " $file
mergeText $file "Seek Out Report.txt" $file
write $file $date & " " & $time & " - Couldnt warp from " & $sector
killTrigger 9
killTrigger 10
setTextTrigger 9 :NoClearAvoids "Clear Avoids?"
setTextTrigger 10 :NoClearAvoids "DANGER! You have marked sector"
goto :MoveSector
pause

:SearchDupePlanet
setVar $file ""
mergeText GAMENAME " - " $file
mergeText $file "Seek Out Report.txt" $file
read $file $temp $i
getWordPos $temp $temp2 $planet
getWordPos $temp $temp3 $CurSector
IF ($temp = EOF)
        return
ELSEIF ($temp2 <> 0) AND ($temp3 <> 0)
        killTrigger 6
        setTextTrigger 6 :FoundPlanet "Planets :"
        pause
ELSE
        add $i 1
        goto :SearchDupePlanet
END


:End
