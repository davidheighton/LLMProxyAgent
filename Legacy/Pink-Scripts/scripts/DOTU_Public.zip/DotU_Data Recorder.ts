#Script Author: Voltron
#Noted Bugs: Rarely grabbing current sector doesnt work. Grabs adjacent sector. 
#Future Plans: None at this time

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Data Recorder 2.0" ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Loads into memory and just records useful data such as aliens, traders, and planets. Searches for duplicate entries for planets and wont write dupes. Date and Time stamps to a file in TWX root directory Recorded Data.txt"
echo ANSI_10 "*Date Made: " ANSI_13 " 12/14/01 "
echo ANSI_10 "*Start Point: " ANSI_13 " Anywhere "
echo ANSI_10 "*Special Notes: " ANSI_13 "Loads as SystemScript. Has to manually unloaded to stop it.*"

SystemScript

:RecordAlienInput
Echo ANSI_12 "*Do you want to record aliens and unmanned ships as well? (Y/N)*"
GetConsoleInput $choice SINGLEKEY
IF ($choice = "Y") OR ($choice = "y")
        setVar $RecordAliens "Y"
ELSEIF ($choice = "N") or ($choice = "n")
        setVar $RecordAliens "N"
ELSE
        goto :RecordAlienInput
END

Echo ANSI_10 "*Script now running in background*"
getTime $time
getDate $date
mergeText GAMENAME " - " $file
mergeText $file GAME $file
mergeText $file " - " $file
mergeText $file "Recorded Data.txt" $file
write $file "Script started on " & $date & " at " & $time


setTextTrigger 1 :NoAvoid "Mined Sector:"
setTextTrigger 2 :FoundPlanet "Planets :"
setTextTrigger 3 :FoundTrader "Federals:"
setTextTrigger 4 :FoundTrader ", w/"
setTextLineTrigger 5 :CurSector "Warping"
pause

:NoAvoid
waitFor "(Y/N)"
send "*"
getTime $time
getDate $date
write $file $date & " " & $time & " - Armid Mines - " & $CurSector
killTrigger 1
setTextTrigger 1 :NoAvoid "Mined Sector:"
pause

:FoundPlanet
setVar $planet CURRENTLINE
getWord $planet $TerraChk 4
IF ($TerraChk = "Terra")
        killTrigger 2
        setTextTrigger 2 :FoundPlanet "Planets :"
ELSE
        stripText $planet "Planets :"
        getTime $time
        getDate $date
        setVar $i 1
        goSub :SearchDupePlanet
        write $file $date & " " & $time & " - Planet - " & $planet & " - " & $CurSector
        killTrigger 2
        setTextTrigger 2 :FoundPlanet "Planets :"
END
pause
:SearchDupePlanet
read $file $temp $i
getWordPos $temp $temp2 $planet
getWordPos $temp $temp3 $CurSector
IF ($temp = EOF)
        return
ELSEIF ($temp2 <> 0) AND ($temp3 <> 0)
        killTrigger 2
        setTextTrigger 2 :FoundPlanet "Planets :"
        pause
ELSE
        add $i 1
        goto :SearchDupePlanet
END

:FoundTrader
setVar $line CURRENTLINE
getWord $line $alien 1
IF ($alien <> "Traders") OR ($alien <> "Federals:")
        goto :FoundShip
END
setVar $trader $line
stripText $trader "Traders : "
stripText $trader "Federals: "
getTime $time
getDate $date
write $file $date & " " & $time & " - Trader - " & $trader & " - " & $CurSector
killTrigger 3
killTrigger 4
setTextTrigger 3 :FoundTrader "Federals:"
setTextTrigger 4 :FoundTrader ", w/"
pause

:FoundShip
IF ($RecordAliens = "Y")
        setVar $ship $line
        getTime $time
        getDate $date
        write $file $date & " " & $time & " - Ship - " & $ship & " - " & $CurSector
END
killTrigger 4
setTextTrigger 4 :FoundTrader ", w/"
pause

:CurSector
setVar $line2 CURRENTLINE
getWord $line2 $warpchk 1
IF ($warpchk = "Auto")
        getWord $line2 $CurSector 5
ELSE
        getWord $line2 $CurSector 4
END
killTrigger 5
setTextLineTrigger 5 :CurSector "Warping"
pause