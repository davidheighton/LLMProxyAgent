#Script Author: Voltron
#Noted Bugs: None
#Future Plans: None

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Warp Finder " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Input a # and it queries TWX database to find sectors with that many warps out. Helpful for finding hidden StarDock and 0 class's. Dumps results to Sector Warps.txt"
echo ANSI_10 "*Date Made: " ANSI_13 "11/26/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Anywhere"
echo ANSI_10 "*Special Notes: " ANSI_13 "Need full TWX ZTM for accuracy. SD has 6 warps, 0 class have 5-7*"

setVar $MaxSectors SECTORS

getInput $warp "Enter # of warps in a sector to find" 6
echo ANSI_9 "*Scanning now. Please wait.*"
setVar $i 1
mergeText GAMENAME " - " $file
mergeText $file GAME $file
mergeText $file " - " $file
mergeText $file $warp $file
mergeText $file " Sector Warps.txt" $file
delete $file

window WarpFind 135 90 "SD Finder" OnTop

:CheckWarps
setWindowContents WarpFind "Max Sectors: " & $MaxSectors & "*Current Sector: " & $i & "*Sec Warps to find: " & $warp & "*Found: " & $i2
if ($i > $MaxSectors)
        goto :End
end
getSector $i $result
if ($result.warps = $warp)
        add $i2 1
        write $file $i
end
add $i 1
goto :CheckWarps

:End
echo ANSI_10 "Search Completed. " $i2 " sectors found and was written to *'" $file "'"