#Script Author: Voltron
#Noted Bugs: None
#Future Plans: None

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " 1 Fig Attack-Infinite" ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Attacks ship u specify by matching the 3rd, or 4th word on the attack prompt (Which is typically first word of ship type), with 1 fig infinitely"
echo ANSI_10 "*Date Made: " ANSI_13 "3/10/02"
echo ANSI_10 "*Start Point: " ANSI_13 "Command prompt"
echo ANSI_10 "*Special Notes: " ANSI_13 "Loops infintely. CASE sensitive*"

getInput $shiptype "Enter ship type to capture, just the first word of ship type, case sensitive"
:Attack
send "A"
killallTriggers
setTextTrigger attackship :Go "Attack "
#setTextTrigger captured :Sub_Capped "The ship is abandoned!"
pause

#Start the attack and verify its the right ship to attack
:Go
getWord CURRENTLINE $ship 3
getWord CURRENTLINE $ship2 4
if ($ship = $shiptype) OR ($ship2 = $shiptype)

        send "Y1*"
        killTrigger attackship
        setTextTrigger attackship :Attack "Attack "
        waitFor "Attack "
else
        send "N"
        killTrigger attackship
        setTextTrigger attackship :Attack "Attack "
        waitFor "Attack "
end
goto :Attack

#Ship has been capped or destroyed, now get back to command prompt
:Sub_Capped
setTextTrigger stop :Stop "Command [TL="
setTextTrigger noattack :NoAttack "(Y/N)"       
pause

:NoAttack
send "N"
killTrigger noattack
setTextTrigger noattack :NoAttack "(Y/N)"       
pause
        
:Stop
send "*"
echo ANSI_12 "**__--==" & $shiptype & " Ship captured or destroyed!!==--__**"
