#Script Author: Voltron
#Noted Bugs: None
#Future Plans: None

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Keep Alive 1.0" ANSI_10 "�" ANSI_12 "���*"
echo ANSI_13 "*Description: Sends # when server is going to time you out"
echo ANSI_13 "*Date Made: 10/5/01"
echo ANSI_13 "*Start Point: Anywhere"
echo ANSI_13 "*Special Notes: Modified version of Xide's in script pack 1*"

:loop
setTextTrigger 1 :AntiIdle "INACTIVITY WARNING:"
pause
:AntiIdle
killTrigger 1
send "#"
goto :loop