#Script Author: Voltron
#Noted Bugs: None
#Future Plans: None

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Ship Info " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Addon for DotU_ShipCapture. Grab all ships in game auto and dump to file od add alien ships manually"
echo ANSI_10 "*Date Made: " ANSI_13 "2/27/02"
echo ANSI_10 "*Start Point: " ANSI_13 "Command prompt"
echo ANSI_10 "*Special Notes: " ANSI_13 "Auto ship grab DELETES the info file. Run before entering any manual ships or edit file yourself and add*"


cutText CURRENTLINE $location 1 7

if ($location <> "Command")
        clientMessage "This script must be run from the game command menu"
        halt
end

# setup File name and reset the file
mergeText GAMENAME " - " $file
mergeText $file "ShipInfo.txt" $file


#Display Main Menu
:MainMenu
echo ANSI_10 "**Main Menu*"
echo ANSI_12 "*<" ANSI_9 "1" ANSI_12 "> Grab all ships automatically from ship computer"
echo ANSI_12 "*<" ANSI_9 "2" ANSI_12 "> Manually add a ship (alien/special ships)"
echo ANSI_12 "*<" ANSI_9 "Q" ANSI_12 "> Quit*"
getConsoleInput $MenuChoice SINGLEKEY
IF ($MenuChoice = 1)
        goto :AutoShip
ELSEIF ($MenuChoice = 2)
        goto :ManShip
ELSEIF ($MenuChoice = "Q")
        halt
ELSE
        goto :MainMenu
END

:ManShip
echo ANSI_12 "**"
getInput $ManShipName "Enter name of Ship to add (CASE and SPACING SENSITIVE, must be exact)" 0
getInput $ManShipShields "Enter max # of shields ship can hold (Ex. 4,000)" 0
getInput $ManShipD "Enter the defense rating of the ship (Ex. 1.4)" 0

echo ANSI_10 "*"
echo $ManShipName "*"
echo $ManShipShields "*"
echo $ManShipD "*"

:ManCorrectPrompt
echo ANSI_10 "Is this Correct? (Y/N)"
getConsoleInput $ManCorrect SINGLEKEY
IF ($ManCorrect = "Y")
        goto :ManSave
ELSEIF ($ManCorrect = "N")
        goto :MainMenu
ELSE
        goto :ManCorrectPrompt
END

:ManSave
write $file "*"
write $file $ManShipName
write $file $ManShipShields
write $file $ManShipD
echo ANSI_9 "Data has been saved"
goto :MainMenu


:AutoShip
delete $file
setVar $i2 1
send "cc"
waitFor "Which ship are you interested in (?=List) ?"
send "?"
setTextTrigger GetShips :GetShips "<"
pause

:GetShips
add $i 1
killAllTriggers
getWord CURRENTLINE $ShipLetter 1
stripText $ShipLetter "<"
stripText $ShipLetter ">"
IF ($ShipLetter = "+")
        goSub :Sub_NextPage
ELSEIF ($ShipLetter = "Q")
        subtract $i 1
        goto :Start
END
cutText CURRENTLINE $ShipName 5 100
setVar $Ship[$i] $ShipLetter
setVar $ShipName[$i] $ShipName
setTextTrigger GetShips :GetShips "<"
pause

:Sub_NextPage
subtract $i 1
IF ($Page2 = "YES")
     WaitFor "Which ship are you interested in"
     send "+"
     goto :Start
END
setVar $Page2 YES
WaitFor "Which ship are you interested in"
send "+"
setTextTrigger GetShips :GetShips "<"
pause


:Start
send $Ship[$i2]
killallTriggers
setTextLineTrigger 1 :Line1 "Ship Category #"
setTextLineTrigger 2 :Line2 "Basic Hold Cost:"
setTextLineTrigger 4 :Line4 "Computer Cost:"
pause

:Line1
setVar $line1 CURRENTLINE
getWordPos $line1 $temp "Ship Class : "
add $temp 13
cutText $line1 $line1 $temp 100
replaceText $line1 " " "_"
write $file $line1
pause

:Line2
setVar $line2 CURRENTLINE
getWordPos $line2 $temp "Maximum Shields:"
cutText $line2 $line2 $temp 100
StripText $line2 "Maximum Shields:"
ReplaceText $line2 " " ""
write $file $line2
pause

:Line4
setVar $line4 CURRENTLINE
getWordPos $line4 $temp "Defensive Odds:"
cutText $line4 $line4 $temp 100
stripText $line4 "Defensive Odds:"
stripText $line4 ":1"
ReplaceText $line4 " " ""
write $file $line4

IF ($i2 = $i)
     send "QQ"
     HALT
ELSEIF ($i2 = 17)
     send "+"
END

add $i2 1
goto :Start
