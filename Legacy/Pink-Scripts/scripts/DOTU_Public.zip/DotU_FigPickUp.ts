#Script Author: NZThorDM
#Noted Bugs: Gets stuck at attack prompt if you dont own all planets. Messes up if u not on a corp
#Future Plans: None

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Planet to sector fig dump " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Grabs all figs off all planets in sector and dumps into sector as corp defensive."
echo ANSI_10 "*Date Made: " ANSI_13 "12/7/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Command prompt"
echo ANSI_10 "*Special Notes: " ANSI_13 "Make sure u on a corp*"



# check if we can run it from here
cutText CURRENTLINE $location 1 7
if ($location <> "Command")
        clientMessage "This script must be run from the game command menu"
        halt
end

send "d"
waitfor "Command [TL="

# First thing is to get info about ship, and figs

# Current ship figs

:getQuickStats
send "/"
setTextLineTrigger 1 :getQStatsA "Turns"

pause

:getQStatsA
setVar $line CURRENTLINE
mergeText $line "�" $line

:getQStatsB
getLength $line $lineLength
getWordPos $line $delimPos "�"

if ($delimPos < 2)
        pause
end

cutText $line $chunk 1 $delimPos
stripText $chunk "�"
stripText $chunk ","
getWord $chunk $variable 1

if ($variable = "Sect")
getWord $chunk $cursec 2
end
if ($variable = "Figs")
getWord $chunk $shipfigs 2
else
add $delimPos 1
cutText $line $line $delimPos 999
goto :getQStatsB
end

# Current sec figs

getSector $cursec $secinfo

# $SECINFO.FIGHTERS.QUANTITY: 0
# $SECINFO.FIGS.OWNER: belong to your Corp
# $SECINFO.FIGS.QUANTITY: 79437  <---  use this one


# get current figs in sec
setvar $figshere $secinfo.figs.quantity

# dump all figs in sec...
add $figshere $shipfigs
waitfor "Command"
send "f" & $figshere & "*cd"
setvar $shipfigs 0

# then get planet numbers and number of planets
setvar $i 0
send "L"
:Startlist
killAllTriggers
setTextTrigger 1 :PlanetList "   <"
setTextTrigger 2 :Endlist "Land on which planet"
pause

#Gets 1st planet, strips everything cept the #, stores it in the array $Planet[] then restarts for next planet in list
:PlanetList
add $i 1
cuttext CURRENTLINE $PlanetNum 4 5
striptext $planetNum " "
stripText $PlanetNum "<"
stripText $PlanetNum ">"
setVar $planet[$i] $PlanetNum
goto :Startlist

:Endlist
killalltriggers
send "q*"
waitfor "Command [TL="
# and work our way thru the list

setvar $count 0
:landloop
add $count 1
:repeatloop
send "l" $planet[$count] "*"
waitfor "Planet command (?=help)"
send "mnt"
settextlinetrigger 1 :getplanetfigs "There are currently"
pause

:getplanetfigs
getword CURRENTLINE $pfigs 4
waitfor "Max"
getword CURRENTLINE $pfigs2 9
cuttext $pfigs2 $pfigs2 2 7
send "*"
add $shipfigs $pfigs2

if ($pfigs = $pfigs2)
        setvar $repeat 0
else
        setvar $repeat 1
end
waitfor "Planet command (?=help)"
send "q"

# dump all figs in sec...
add $figshere $shipfigs
waitfor "Command [TL="
send "f" & $figshere & "*cd"
setvar $shipfigs 0

if ($repeat = 1)
        goto :repeatloop
elseif ($count <> $i)
        goto :landloop
end


# then leave 1 fig if not enough figs to fill us, or leave the rest if is enough to fill
waitfor "Command [TL"
send "f"

settextlinetrigger 1 :getfigs "Your ship can support up to"
pause

:getfigs
getword CURRENTLINE $leavefigs 10
if ($leavefigs = 0)
        send "1*cd"
else
        send $leavefigs "*cd"
end
