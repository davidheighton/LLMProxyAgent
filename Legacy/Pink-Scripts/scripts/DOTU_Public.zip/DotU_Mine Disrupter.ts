#Script Author: Voltron
#Noted Bugs: None
#Future Plans: None

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Mine Disruptor " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Displays menu of mines in adjacent sectors"
echo ANSI_10 "*Date Made: " ANSI_13 "12/6/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Command prompt"
echo ANSI_10 "*Special Notes: " ANSI_13 "Need to have Holo Scanner for realtime info *"


cutText CURRENTLINE $location 1 7
IF ($location <> "Command")
        clientMessage "This script must be run from the game command menu"
        halt
END
getWord CURRENTLINE $cursec 2
stripText $cursec "[TL=00:00:00]:["
stripText $cursec "]"
getSector $cursec $secinfo
send "SH"
waitFor "Command [TL="

#Display Available Warps Menu
echo ANSI_10 "**Which sector?"
:Loop
IF ($i = $secinfo.warps)
     echo ANSI_12 "*<" ANSI_9 "Q" ANSI_12 "> Quit*"
     goto :MenuChk
END
add $i 1
getSector $secinfo.warp[$i] $secmines
echo ANSI_12 "*<" ANSI_9 $i ANSI_12 "> " $secinfo.warp[$i] " - " ANSI_10 $secmines.armidmines.quantity ANSI_12 " mines owned by " $secmines.armidmines.owner
goto :Loop

#Menu displayed, now get sector choice
:MenuChk
getConsoleInput $MenuChoice SINGLEKEY
IF ($MenuChoice = 1)
     setVar $disruptsec $secinfo.warp[1]
ELSEIF ($MenuChoice = 2)
     setVar $disruptsec $secinfo.warp[2]
ELSEIF ($MenuChoice = 3)
     setVar $disruptsec $secinfo.warp[3]
ELSEIF ($MenuChoice = 4)
     setVar $disruptsec $secinfo.warp[4]
ELSEIF ($MenuChoice = 5)
     setVar $disruptsec $secinfo.warp[5]
ELSEIF ($MenuChoice = 6)
     setVar $disruptsec $secinfo.warp[6]
ELSEIF ($MenuChoice = "Q")
     halt
ELSE
     echo ANSI_10 "*Invalid Choice*"
     goto :MenuChk
END

send "C"
:Disrupt
killAllTriggers
#Get to fire disrupter prompt
send "W"
setTextTrigger go :Go "Do you wish to launch one ?"
setTextTrigger nogo :NoGo "You do not "
pause

:Go
send "Y" $disruptsec "*"
setTextTrigger MinesRemain :MinesRemain "You destroyed"
pause
:MinesRemain
getWord CURRENTLINE $result 3
IF ($result = "all")
     send "Q"
     echo "*[31;5mAll mines destroyed*[0m"
     halt
END
goto :Disrupt

:NoGo
send "Q"
waitFor "Command [TL="
send "SH"
echo ANSI_10 "*All out of mines, go get more at SD*"
