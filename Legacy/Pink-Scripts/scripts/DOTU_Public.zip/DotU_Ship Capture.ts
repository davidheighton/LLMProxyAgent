#Script Author: Voltron
#Noted Bugs: Sometimes 2nd shot over calculates for some reason and blows target. Havent figured out why yet
#Future Plans: Clean up code. Change from menu to activate like Tweety's at the Attack prompt and auto complete figs to use.

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Ship Capture " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Calculates exact # of figs to cap and attempts to cap it. If no combat scanner, assumes 0 shields so dont blow accid."
echo ANSI_10 "*Date Made: " ANSI_13 "11/9/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Command"
echo ANSI_10 "*Special Notes: " ANSI_13 "2nd shots sometimes mess up and too much is used. *"


mergeText GAMENAME " - " $file
mergeText $file GAME $file
mergeText $file " - " $file
mergeText $file "ShipInfo.txt" $file

fileExists $ShipFile $file
IF ($ShipFile = "FALSE")
        echo ANSI_10 "No ship database file found. Rerun DotU_ShipInfo."
        HALT
END

#Get current figs
goSub :Sub_GetCurFigs

#Get current ship type you in
send "C;"
setTextLineTrigger ORating :ORating "Main Drive Cost:"
pause
##########Grabs odds for your ship
:ORating
getWordPos CURRENTLINE $temp "Offensive Odds:"
cutText CURRENTLINE $ORating $temp 19
stripText $ORating "Offensive Odds:"
replaceText $ORating " " ""
stripText $ORating "."

##########Get ships in current sector
send "Q"
waitFor "Command [TL="
send "D"
setTextLineTrigger ship :ShipSearch ", w/"
setTextLineTrigger shipclass :ShipClass " ("
setTextTrigger menu :Menu "Command [TL="
pause

##########Finds and records all ships in this sector in an array $ship[]
:ShipSearch
add $i 1
getText CURRENTLINE $shipfigs[$i] ", w/" "ftrs,"
getWordPos CURRENTLINE $line ":"
if ($line = 9)
     add $line 2
else
     setVar $line 11
end
getWordPos CURRENTLINE $line2 ", w/"
subtract $line2 $line
cutText CURRENTLINE $shipowner $line $line2
stripText $line ","
setVar $ship[$i] $shipowner
if ($i = 11)
     setVar $i 10
     goto :Menu
end
killTrigger ship
setTextLineTrigger ship :ShipSearch ", w/"
pause

##########Finds and records all shiptypes in this sector in an array $shiptype[]

:ShipClass
getWordPos CURRENTLINE $line3 "("
getWordPos CURRENTLINE $line4 ")"
setVar $line5 $line3
subtract $line5 2
getWord $line5 $line5 1
isNumber $line5 $line5
if ($line5 = "FALSE")
     goto :MenuDone
end
cutText CURRENTLINE $shiptype $line3 $line4
stripText $shiptype "("
stripText $shiptype ")"
#replaceText $shiptype " " "_"
setVar $shiptype[$i] $shiptype
if ($i = 11)
     setVar $i 10
     goto :Menu
end
killTrigger shipclass
setTextLineTrigger shipclass :ShipClass " ("
pause

##########We have all ships in sec now, make the menu
:Menu
killAllTriggers
setVar $totalships $i
setVar $i 1
setVar $title 1
:MenuPrompt
##########So we dont repeat the title
if ($title = 1)
     echo "*" ANSI_15 "Select which ship you want to capture:" "**"
end
echo ANSI_11 "<" $i ">" ANSI_12 " - " $ship[$i] " - " ANSI_9 $shiptype[$i] ANSI_14 " (" & $shipfigs[$i] & "figs)*"
if ($i < $totalships)
     setVar $title 0
     add $i 1
     goto :MenuPrompt
end
echo ANSI_11 "<Q>" ANSI_12 " - Quit*"
:MenuDone
getConsoleInput $SelectedShip SINGLEKEY
IF ($SelectedShip = 1) OR ($SelectedShip = 2) OR ($SelectedShip = 3) OR ($SelectedShip = 4) OR ($SelectedShip = 5) OR ($SelectedShip = 6) OR ($SelectedShip = 7) OR ($SelectedShip = 8) OR ($SelectedShip = 9) OR ($SelectedShip = 0)
     setVar $EShipFigs $shipfigs[$SelectedShip]
     goto :Attack
ELSEIF ($SelectedShip = "Q")
     halt
ELSE
     goto :Menu
END

#$i2 used for word pos when findin ship to attack
:Attack
setVar $i2 6
killAllTriggers
send "A"
setTextTrigger attackship :Go "Attack "
pause

#Start the attack and verify its the right ship to attack. $i2 = counter for word pos
:Go
getWord $ship[$SelectedShip] $ship $i2
#Find last word in persons name
IF ($i2 = 0)
     send "SH"
     echo ANSI_12 "**Ship No Longer In Sector**"
     HALT
ELSEIF ($ship = 0)
     subtract $i2 1
     goto :Go
END

getWordPos CURRENTLINE $result $Ship
IF ($result <> 0)
     #attack prompt
     goSub :Sub_GetEnemyShip
     goSub :Sub_GetCurFigs
     goSub :Sub_GetCurEFigs
     send "Y"
     killTrigger attackship
     #reset counter for lines when reading shields from file
     setVar $i3 0
     goSub :Sub_Maxshields
     setTextTrigger GetShields :GetShields "Combat scanners"
     setTextTrigger Ready :Ready "How many fighters do you wish to use (0"
     pause

     :GetShields
          killTrigger GetShields
          getWord CURRENTLINE $Shields 7
          stripText $Shields "%"
          multiply $Shields $MaxShields
          divide $Shields 100
          pause

     :Ready
          killTrigger Ready
          #Get your current figs, save as $MaxFigs, $shipfigs[$SelectedShip] = enemy figs, $EnemyShip = enemy ship
          getWord CURRENTLINE $MaxFigs 11
          stripText $MaxFigs ","
          stripText $MaxFigs ")"
          #add enemy figs with shields
          stripText $EShipFigs ","
          replaceText $EShipFigs " " ""
          add $Shields $EShipFigs
          #add in the D Rating
          multiply $Shields $DRating
          #change DRating back to decimal format
          divide $Shields 10
          #add in O Rating and attack
          divide $Shields $ORating
          multiply $Shields 10

          IF ($CurFigs < $Shields)
               clientMessage "Not enough figs to cap ship, needs " $Shields
               HALT
          ELSEIF ($MaxFigs < $Shields)
                send $MaxFigs "*"
          ELSEIF ($Shields = 0)
                send "1*"
          ELSE
               send $Shields "*"
          END
          #Loop if not cap'd
          setTextTrigger captured :Sub_Capped "The ship is abandoned!"
          setTextTrigger NotCapd :Attack "Command [TL="
          setTextTrigger LeftSec :LeftSec "warps out of the sector!"
          setTextTrigger Obliterated :Sub_Dest "Excellent, you have obliterated the target!"
          setTextTrigger Destroyed :Sub_Dest "You destroyed the ship"
          pause

ELSE
     send "N"
END

goto :Attack

:Sub_GetCurEFigs
setTextTrigger GetCurEFigs :Sub_Sub_GetCurEFigs "(Y/N) [N]?"
pause
:Sub_Sub_GetCurEFigs
setVar $currentline CURRENTLINE
getWordPos $currentline $result "-"
getWordPos $currentline $result2 ")"
add $result 1
subtract $result2 $result
cutText $currentline $EShipFigs $result $result2
return

:Sub_GetEnemyShip
setVar $currentline CURRENTLINE
getWordPos $currentline $result2 "'s"
getWordPos $currentline $result3 "("
add $result2 3
subtract $result3 1
subtract $result3 $result2
cutText $currentline $EnemyShip $result2 $result3
stripText $EnemyShip "unmanned "
ReplaceText $EnemyShip " " "_"
return

:Sub_MaxShields
add $i3 1
read $file $temp $i3
IF ($temp = EOF)
     echo ANSI_12 "**Cannot find ship in database, rerun ShipInfo or add manually"
     send "*"
     HALT
END
setVar $ship $EnemyShip
getWordPos $temp $result $ship
IF ($result = 0)
     goto :Sub_MaxShields
ELSE
     add $i3 1
     read $file $temp $i3
     getWord $temp $MaxShields 1
     stripText $MaxShields ","
     add $i3 1
     read $file $temp $i3
     getWord $temp $DRating 1
     stripText $DRating "."
     return
END

:Sub_GetCurFigs
#Get current figs
send "/"
setTextLineTrigger GetCurFigs :Sub_Sub_GetCurFigs "Figs"
pause
:Sub_Sub_GetCurFigs
killTrigger GetCurFigs
getWord CURRENTLINE $CurFigs 5
stripText $CurFigs "�Shlds"
stripText $CurFigs ","
return

#Ship has been capped or destroyed
:Sub_Capped
killAllTriggers
send "*"
echo ANSI_12 "**__--==" & $shiptype[$SelectedShip] & " captured!! ==--__**"
HALT

:LeftSec
send "SH"
echo ANSI_12 "**Ship No Longer In Sector**"
HALT

:Sub_Dest
killAllTriggers
send "*"
echo ANSI_12 "**__--==" & $shiptype[$SelectedShip] & " destroyed!! ==--__**"
