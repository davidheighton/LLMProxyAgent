#Script Author: NZThorDM
#Noted Bugs: Sometimes window updates faster then the server and #'s are off
#Future Plans: Expand to a Move_Colo possibly

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Move Product " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Moves product from one planet to another, doesnt have to be same sec either"
echo ANSI_10 "*Date Made: " ANSI_13 "11/11/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Planet prompt of source planet, not target planet"
echo ANSI_10 "*Special Notes: " ANSI_13 "Assumes PScanner, or multiple planets in sec. Must have clear path to target sector. Xide's script modified to add window support.*"


# check if we can run it from here
cutText CURRENTLINE $location 1 14

if ($location <> "Planet command")
        clientMessage "This script must be run from the surface of a planet"
        halt
end

logging off

# show script banner
echo "**" ANSI_3 "     --" ANSI_11 "===| " ANSI_15 "Move Product v1.01" ANSI_11 " |===" ANSI_3 "--**"
echo ANSI_7 "This script is freeware and may be distributed."
echo ANSI_7 "**For script information please refer to Pack1.txt.*This script is subject to the license agreement*as stated in License.txt."
echo "**" ANSI_15 "Please read the warnings written at the top of*the script before using it!*"

:GetProduct
echo "*" ANSI_15 "Select Product:" "**"
echo ANSI_11 "1 " ANSI_3 " - Fuel Ore*"
echo ANSI_11 "2 " ANSI_3 " - Organics*"
echo ANSI_11 "3 " ANSI_3 " - Equipment*"
getConsoleInput $Product SINGLEKEY

if ($Product <> 1) and ($Product <> 2) and ($Product <> 3)
  goto :GetProduct
end

if ($Product = 1)
        setvar $namep "Fuel"
elseif ($Product = 2)
        setvar $namep "Organics"
elseif ($Product = 3)
        setvar $namep "Equipment"
end

getinput $planet2 "Enter planet ID to move to" 0
getinput $sector2 "Enter sector of planet to move to (S = same sector)" 0
getinput $quantity "Enter quantity to move" 0

# Set trigger to stop script if disconnected
setEventTrigger 0 :End "Connection lost"

# get the planet number for the planet we're on
send "d"
setTextLineTrigger 1 :getPlanet "Planet #"
pause
:getPlanet
getWord CURRENTLINE $planet1 2
stripText $planet1 "#"

# get the sector we're in
send "qd"
setTextLineTrigger 1 :getSector "Sector  : "
pause
:getSector
getWord CURRENTLINE $sector1 3

# get the distance between sectors
if ($sector1 = $sector2) or ($sector2 = "S") or ($sector2 = "s")
        setVar $distance 0
else
        send "cf" "*" $sector2 "*q"
        setTextLineTrigger 1 :getDistance "The shortest path"
        pause
        :getDistance
        getWord CURRENTLINE $distance 4
        stripText $distance "("
end
send "l" $planet1 "*"

# get the total free holds in this ship
setTextLineTrigger 1 :getHolds "You have "
pause
:getHolds
getWord CURRENTLINE $holds 3

# don't run script without free cargo holds
if ($holds = 0)
        clientMessage "No free cargo holds!"
        halt
end

# calculate exactly how many trips we're making
# and how much we're carrying on our last trip
setVar $trips $quantity
divide $trips $holds
setVar $x $trips
multiply $x $holds
setVar $lastTrip $quantity
subtract $lastTrip $x
if ($lastTrip = 0)
        setVar $lastTrip $holds
else
        add $trips 1
end

setTextTrigger 1 :sub_Done "There aren't that many on the planet"
setVar $twarp 0

window togo 200 100 "Move Information" yes

# away we go!
:sub_Move
        setvar $temp $holds
        multiply $temp $trips
        setWindowContents togo "Moving " & $namep & "*From planet " & $planet1 & " to " & $planet2 & "*" & $namep & " left to move = " & $temp

        send "tnt" $product

        # if its the last trip, we may need to carry an amount not
        # equal to the ship's max free cargo holds in order to make
        # the total quantity moved equal to the desired quantity moved
        if ($trips = 1)
                send $lastTrip "*q"
        else
                send "*q"
        end

        if ($distance > 0)
                send $sector2
                if (SECTORS > 5000) or ($sector2 < 600)
                        send "*"
                end
        end

        if ($distance > 1)
                if ($twarp = 0)
                        # we don't know if this ship can twarp yet
                        # so we find out now
                        setTextTrigger 2 :setTwarp "Do you want to engage"
                        setTextTrigger 3 :setNoTwarp "The shortest path"
                        pause
                        :setTwarp
                        killTrigger 3
                        setVar $twarp "Y"
                        goto :gotTwarp
                        :setNoTwarp
                        killTrigger 2
                        setVar $twarp "N"
                        :gotTwarp
                end

                if ($twarp = "Y") then
                        # twarp capable ship - add an extra "n"
                        send "ne"
                else
                        send "e"
                end

        end

        send "l" $planet2 "*tnl" $product "*q"

        if ($distance > 0)
                send $sector1
                if (SECTORS > 5000) or ($sector1 < 600)
                        send "*"
                end
        end

        if ($distance > 1)
                if ($twarp = "Y")
                        send "ne"
                else
                        send "e"
                end
        end

        send "l" $planet1 "*"
        mergeText "Planet #" $planet2 $waitText
        waitFor $waitText
        subtract $trips 1

        if ($trips > 0)
                goto :sub_Move
        end

:sub_Done
        # transferred it all
        halt

:End
