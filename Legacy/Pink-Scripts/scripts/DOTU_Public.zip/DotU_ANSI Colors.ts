#Script Author: Voltron
#Noted Bugs: None 
#Future Plans: None

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " TWX Colors " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Lists TWX's possible color and formatting and escape keys"
echo ANSI_10 "*Date Made: " ANSI_13 "9/16/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Anywhere "
echo ANSI_10 "*Special Notes: " ANSI_13 "In script body is more Escape Characters *"

echo ANSI_1 "*This is ANSI_1 - Dark Blue *"
echo ANSI_2 "This is ANSI_2 - Dark Green*"
echo ANSI_3 "This is ANSI_3 - Dark Light Blue*"
echo ANSI_4 "This is ANSI_4 - Dark Red*"
echo ANSI_5 "This is ANSI_5 - Dark Purple*"
echo ANSI_6 "This is ANSI_6 - Dark Yellow*"
echo ANSI_7 "This is ANSI_7 - Dark White*"
echo ANSI_8 "This is ANSI_8 - Grey*"
echo ANSI_9 "This is ANSI_9  - Blue*"
echo ANSI_10 "This is ANSI_10 - Green*"
echo ANSI_11 "This is ANSI_11 - Light Blue*"
echo ANSI_12 "This is ANSI_12 - Red*"
echo ANSI_13 "This is ANSI_13 - Purple*"
echo ANSI_14 "This is ANSI_14 - Yellow*"
echo ANSI_15 "This is ANSI_15 - White*"

echo ANSI_12 "**Escape Characters and Codes*"
echo "*ESC[0m - [0mAll attributes OFF[0m"
echo "*ESC[1m - [1mBold ON[0m"
echo "*ESC[4m - [4mUnderscore ON (monochrome displays only)[0m"
echo "*ESC[5m - [5mBlink ON[0m"
echo "*ESC[7m - Inverse Video (Supported by very few terminals)"
echo "*ESC[8m - [8mInvisible ON[0m"
echo "*ESC[30m - [30;47mBlack[0m"
echo "*ESC[31m - [31mRed[0m"
echo "*ESC[32m - [32mGreen[0m"
echo "*ESC[33m - [33mYellow[0m"
echo "*ESC[34m - [34mBlue[0m"
echo "*ESC[35m - [35mMagenta[0m"
echo "*ESC[36m - [36mCyan[0m"
echo "*ESC[37m - [37mWhite[0m"
echo "*ESC[40m - [40mBlack Background[0m"
echo "*ESC[41m - [41mRed Background[0m"
echo "*ESC[42m - [42mGreen Background[0m"
echo "*ESC[43m - [43mYellow Background[0m"
echo "*ESC[44m - [44mBlue Background[0m"
echo "*ESC[45m - [45mMagenta Background[0m"
echo "*ESC[46m - [46mCyan Background[0m"
echo "*ESC[47m - [30;47mWhite Background[0m"
echo "*[32;44mDANGER DANGER![0m - ESC[32;44mDANGER DANGER!ESC[0m (ESC=ASCII code 27)"
HALT

#ESC[2J - Erase Display (ED) - Clears the screen and moves to the home position

#Syntax for Escape Characters
#       ESC[#;...;#m - Set Graphics Rendition (SGR)
#Example
#       Red text with a blue background. Only the word RED is blinking. Also turned off all colors and format at the end.
#       ECHO "*[0;31;44mThis is [5mRed[0;31;44m with a Blue Background and Red is blinking[0m"

#ESC[65;81p - reassigns A to become Q
#ESC[0;68;"DIR";13p - reassigns the F10 key to DIR + [CR]
#ASCII Code-- Extended Key
#16 - 25 ALT Q,W,E,R,T,Y,U,I,O,P
#30 - 38 ALT A,S,D,F,G,H,J,K,L
#44 - 40 ALT Z,X,C,V,B,N,M
#59 - 68 [F1] through [F10]
#84 - 93 SHIFT[F1] through SHIFT[F10]
#94 - 103 [F1] through [F10]
#104 - 113 ALT[F1] through ALT[F10]

#Key        Shift   Ctrl   Alt
#F1  0;59   0;84    0;94   0;104
#F2  0;60   0;85    0;95   0;105
#F3  0;61   0;86    0;96   0;106
#F4  0;62   0;87    0;97   0;107
#F5  0;63   0;88    0;98   0;108
#F6  0;64   0;89    0;99   0;109
#F7  0;65   0;90    0;100  0;110
#F8  0;66   0;91    0;101  0;111
#F9  0;67   0;92    0;102  0;112
#F10 0;68   0;93    0;103  0;113
#F11 0;133  0;135   0;137  0;139
#F12 0;134  0;136   0;138  0;140
#End 0;79   49      0;117  0;159
