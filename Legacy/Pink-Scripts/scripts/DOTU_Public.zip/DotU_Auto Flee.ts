#Script Author: Voltron
#Noted Bugs: Cant chk if port was blown before enemy attacks u. So you could possibly die that way.
#Future Plans: May later revise and add twarp'n and Smart Evasive Warping

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Auto Flee " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Tries to escape enemy while u afk. Tries to port, if cant will run to terra and land"
echo ANSI_10 "*Date Made: " ANSI_13 "11/26/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Anywhere"
echo ANSI_10 "*Special Notes: " ANSI_13 "Really not the most useful. Easily fooled. *"

setTextTrigger AutoFlee :Lookout "powering up weapons systems!"
pause

:Lookout

# get the current sector
send "d"
setTextLineTrigger 1 :getSectorNumber "Sector  : "
pause
:getSectorNumber
getWord CURRENTLINE $currentSector 3




getSector $currentSector $sectInfo

IF ($sectinfo.port.exists <> 1)
        send "NT*"
        waitFor "Command [TL="
        send "L1*"
ELSE 
        send "PT"
END

killTrigger AutoFlee
setTextTrigger AutoFlee :Lookout "powering up weapons systems!"
setTextTrigger WarpIn :Lookout "warps into the sector."
pause

:End