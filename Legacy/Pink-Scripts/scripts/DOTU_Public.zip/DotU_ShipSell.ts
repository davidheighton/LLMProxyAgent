#Script Author: Voltron
#Noted Bugs: None
#Future Plans: None

echo ANSI_12 "*                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Ship Sell 1.0 " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_13 "*Description: Sells all ships at StarDock"
echo ANSI_13 "*Start Point: Stardock, Command menu"
echo ANSI_13 "*Special Notes: Make sure u wanna sell all at SD. Original idea from Survey_Says"

send "D"
setTextTrigger Start :Go "Stargate Alpha I"
setTextTrigger NoGo :NoGo "Command [TL="
pause

:NoGo
clientMessage "Not at Stardock location"
halt

:Go
killTrigger NoGo
send "PS*S"
:Start
send "S"
KillAllTriggers
setTextLineTrigger 1 :GetShipNum "  0   "
setTextTrigger 2 :Done "You do not own any other ships orbiting the Stardock!"
setTextLineTrigger 3 :GetCash "credits richer!"
pause

:GetShipNum
killTrigger 2
setVar $line CURRENTLINE
getWord $line $shipnum 1
waitFor "Choose which ship to sell (Q=Quit)"
send $shipnum "*Y"
add $i 1
goto :Start

:GetCash
getWord CURRENTLINE $credits 1
stripText $credits ","
add $CredTotal $credits
killTrigger 3
setTextTrigger 3 :GetCash "credits richer!"
pause

:Done
killAllTriggers
echo ANSI_12 "**You sole " $i " ships. You made " $CredTotal " credits."
