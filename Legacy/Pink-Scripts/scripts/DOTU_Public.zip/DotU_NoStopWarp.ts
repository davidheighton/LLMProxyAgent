#Script Author: Voltron
#Noted Bugs: Other helpers with toll/def fig killing can make it mess up
#Future Plans: None

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " No Stop Warping " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Wont stop for nuttin unless conditions are outside of set parameters. Very fast attackin of figs"
echo ANSI_10 "*Date Made: " ANSI_13 "12/6/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Anywhere"
echo ANSI_10 "*Special Notes: " ANSI_13 "It EWarps everywhere and CANNOT be stopped. Be VERY careful. Also loaded as System Script, has to be stopped manually. First script to use dynamic config files*"

systemScript

setVar $1stTime 1
#Adding "test" to end of cfg file
write .\scripts\NoStopWarp.cfg "test"
#Loading 1st line of cfg file into temp variable
read .\scripts\NoStopWarp.cfg $result 1
#Testing to see if that temp variable = test which would mean its new file. If it <> test, then its already got settings saved
IF ($result = "test")
     delete .\scripts\NoStopWarp.cfg
     echo ANSI_10 "**Config file not found. Lets set 'em up*"
     goto :SetupSettingsMenu
END
echo ANSI_10 "**Config file found. Loading settings"
setVar $1stTime 0
#Grabs any possible settings into variables for script to use
read .\scripts\NoStopWarp.cfg $DFigs 1
read .\scripts\NoStopWarp.cfg $MaxDFigs 2
read .\scripts\NoStopWarp.cfg $OFigs 3
read .\scripts\NoStopWarp.cfg $MaxOFigs 4
read .\scripts\NoStopWarp.cfg $TFigs 5
read .\scripts\NoStopWarp.cfg $MaxTFigs 6
#Just resets the file and gets rid of the "test" written earlier
delete .\scripts\NoStopWarp.cfg
write .\scripts\NoStopWarp.cfg $DFigs
write .\scripts\NoStopWarp.cfg $MaxDFigs
write .\scripts\NoStopWarp.cfg $OFigs
write .\scripts\NoStopWarp.cfg $MaxOFigs
write .\scripts\NoStopWarp.cfg $TFigs
write .\scripts\NoStopWarp.cfg $MaxTFigs

:MainMenu
Echo "**Main Menu*"
echo ANSI_12 "*<" ANSI_9 "1" ANSI_12 "> Run script in background with current settings"
echo ANSI_12 "*<" ANSI_9 "2" ANSI_12 "> View Current Settings"
echo ANSI_12 "*<" ANSI_9 "3" ANSI_12 "> Change Current Settings"
echo ANSI_12 "*<" ANSI_9 "Q" ANSI_12 "> Quit*"
getConsoleInput $MenuChoice SINGLEKEY
IF ($MenuChoice = 1)
     IF ($1stTime = 1)
          echo ANSI_10 "*You're not setup yet. Let's go back to settings*"
          goto :SetupSettingsMenu
     END
     echo ANSI_10 "*Script is now Running, go ahead and do whatever :)*"
     goto :StartScript
ELSEIF ($MenuChoice = 2)
     echo ANSI_9 "*Attack Defensive Figs = " ANSI_10 $DFigs
     echo ANSI_9 "*Max Defensive Figs to go thru = " ANSI_10 $MaxDFigs
     echo ANSI_9 "*Attack Offensive Figs = " ANSI_10 $OFigs
     echo ANSI_9 "*Max Offensive Figs to go thru = " ANSI_10 $MaxOFigs
     echo ANSI_9 "*Attack Toll Figs = " ANSI_10 $TFigs
     echo ANSI_9 "*Max Toll Figs to go thru = " ANSI_10 $MaxTFigs
     goto :MainMenu
ELSEIF ($MenuChoice = 3)
     goto :SetupSettingsMenu
ELSEIF ($MenuChoice = "Q")
     halt
END

:SetupSettingsMenu
echo ANSI_12 "*<" ANSI_9 "1" ANSI_12 "> " $DFigs " = Attack Defensive Figs?"
echo ANSI_12 "*<" ANSI_9 "2" ANSI_12 "> " $MaxDFigs " = Max Defensive Figs to go thru"
echo ANSI_12 "*<" ANSI_9 "3" ANSI_12 "> " $OFigs " = Attack Offensive Figs?"
echo ANSI_12 "*<" ANSI_9 "4" ANSI_12 "> " $MaxOFigs " = Max Offensive Figs to go thru"
echo ANSI_12 "*<" ANSI_9 "5" ANSI_12 "> " $TFigs " = Attack Toll Figs?"
echo ANSI_12 "*<" ANSI_9 "6" ANSI_12 "> " $MaxTFigs " = Max Toll Figs to go thru"
echo ANSI_12 "*<" ANSI_9 "S" ANSI_12 "> Save, & Back to Main Menu"
echo ANSI_12 "*<" ANSI_9 "Q" ANSI_12 "> No Save, & Back to Main Menu**"
getConsoleInput $MenuChoice SINGLEKEY
IF ($MenuChoice = 1)
     goto :DFigMenu
ELSEIF ($MenuChoice = 2)
     goto :MaxDFigMenu
ELSEIF ($MenuChoice = 3)
     goto :OFigMenu
ELSEIF ($MenuChoice = 4)
     goto :MaxOFigMenu
ELSEIF ($MenuChoice = 5)
     goto :TFigMenu
ELSEIF ($MenuChoice = 6)
     goto :MaxTFigMenu
ELSEIF ($MenuChoice = "S")
     goto :Save
ELSEIF ($MenuChoice = "Q")
     goto :NoSave
ELSE
     echo ANSI_10 "Not a Valid Choice*"
     goto :SetupSettingsMenu
END

:DFigMenu
echo ANSI_9 "Attack D Figs: Enter Y or N"
getConsoleInput $MenuChoice SINGLEKEY
IF ($MenuChoice = "Y")
     setVar $DFigs "Y"
     goto :SetupSettingsMenu
ELSEIF ($MenuChoice = "N")
     setVar $DFigs "N"
     goto :SetupSettingsMenu
ELSE
     echo ANSI_10 "Not a Valid Choice*"
     goto :DFigMenu
END

:MaxDFigMenu
echo ANSI_9
getInput $MenuChoice2 "Max D Figs to attack: Enter #" 1
isNumber $result $MenuChoice2
IF ($result = "TRUE")
     setVar $MaxDFigs $MenuChoice2
     goto :SetupSettingsMenu
ElSE
     echo ANSI_10 "Not a valid number*"
     goto :MaxDFigMenu
END

:OFigMenu
echo ANSI_9 "Attack O Figs: Enter Y or N"
getConsoleInput $MenuChoice SINGLEKEY
IF ($MenuChoice = "Y")
     setVar $OFigs "Y"
     goto :SetupSettingsMenu
ELSEIF ($MenuChoice = "N")
     setVar $OFigs "N"
     goto :SetupSettingsMenu
ELSE
     echo ANSI_10 "Not a Valid Choice*"
     goto :OFigMenu
END

:MaxOFigMenu
echo ANSI_9
getInput $MenuChoice2 "Max O Figs to attack: Enter #" 1
isNumber $result $MenuChoice2
IF ($result = "TRUE")
     setVar $MaxOFigs $MenuChoice2
     goto :SetupSettingsMenu
ElSE
     echo ANSI_10 "Not a valid number*"
     goto :MaxOFigMenu
END

:TFigMenu
echo ANSI_9 "Attack T Figs: Enter Y or N "
getConsoleInput $MenuChoice SINGLEKEY
IF ($MenuChoice = "Y")
     setVar $TFigs "Y"
     goto :SetupSettingsMenu
ELSEIF ($MenuChoice = "N")
     setVar $TFigs "N"
     goto :SetupSettingsMenu
ELSE
     echo ANSI_10 "Not a Valid Choice*"
     goto :TFigMenu
END

:MaxTFigMenu
echo ANSI_9
getInput $MenuChoice2 "Max T Figs to attack: Enter #" 1
isNumber $result $MenuChoice2
IF ($result = "TRUE")
     setVar $MaxTFigs $MenuChoice2
     goto :SetupSettingsMenu
ElSE
     echo ANSI_10 "Not a valid number*"
     goto :MaxTFigMenu
END

:Save
setVar $1stTime 0
delete .\scripts\NoStopWarp.cfg
write .\scripts\NoStopWarp.cfg $DFigs
write .\scripts\NoStopWarp.cfg $MaxDFigs
write .\scripts\NoStopWarp.cfg $OFigs
write .\scripts\NoStopWarp.cfg $MaxOFigs
write .\scripts\NoStopWarp.cfg $TFigs
write .\scripts\NoStopWarp.cfg $MaxTFigs
echo ANSI_10 "Settings have been saved*"
goto :MainMenu

:NoSave
echo ANSI_10 "Settings were NOT saved*"
IF ($1stTime = 1)
     echo ANSI_10 "You need to save settings at least once*"
ELSE
     read .\scripts\NoStopWarp.cfg $DFigs 1
     read .\scripts\NoStopWarp.cfg $MaxDFigs 2
     read .\scripts\NoStopWarp.cfg $OFigs 3
     read .\scripts\NoStopWarp.cfg $MaxOFigs 4
     read .\scripts\NoStopWarp.cfg $TFigs 5
     read .\scripts\NoStopWarp.cfg $MaxTFigs 6
END
goto :MainMenu


:StartScript
killAllTriggers
setTextTrigger 1 :DFigs "[Defensive]"
setTextTrigger 2 :OFigs "[Offensive]"
setTextTrigger 3 :TFigs "[Toll]"
setTextTrigger 4 :StopPrompt "Stop in this sector"
setTextTrigger 5 :Mines "Mined Sector:"
pause

:DFigs
killTrigger 6
killTrigger 7
setTextTrigger 6 :FigsGone "Command [TL="
setTextTrigger 7 :DFigLoop "Your fighters: "
pause

:DFigLoop
IF ($DFigs = "N")
     send "R"
     echo ANSI_10 "*Killing of Defensive figs is disabled. Retreating*"
     goto :StartScript
END
getWord CURRENTLINE $enemyfigs 6
getWord CURRENTLINE $yourfigs 3
stripText $enemyfigs ","
stripText $yourfigs ","
IF ($enemyfigs > $MaxDFigs)
     send "R"
     echo ANSI_10 "*Too many figs for current setting. Retreating*"
     goto :StartScript
ELSEIF ($enemyfigs > $yourfigs)
     send "R"
     echo ANSI_10 "*They have more figs then you. Retreating*"
     goto :StartScript
ELSE
send "A"
waitFor "Option? ("
send "9999*"
goto :DFigs
END


:OFigs
killTrigger 6
killTrigger 7
setTextTrigger 6 :FigsGone "Command [TL="
setTextTrigger 7 :OFigLoop "Your fighters: "
pause

:OFigLoop
IF ($OFigs = "N")
     send "R"
     echo ANSI_10 "*Killing of Offensive figs is disabled. Retreating*"
     goto :StartScript
END
getWord CURRENTLINE $enemyfigs 6
getWord CURRENTLINE $yourfigs 3
stripText $enemyfigs ","
stripText $yourfigs ","
IF ($enemyfigs > $MaxOFigs)
     send "R"
     echo ANSI_10 "*Too many figs for current setting. Retreating*"
     goto :StartScript
ELSEIF ($enemyfigs > $yourfigs)
     send "R"
     echo ANSI_10 "*They have more figs then you. Retreating*"
     goto :StartScript
ELSE
send "A"
waitFor "Option? ("
send "9999*"
goto :OFigs
END


:TFigs
killTrigger 6
killTrigger 7
setTextTrigger 6 :FigsGone "Command [TL="
setTextTrigger 7 :TFigLoop "Your fighters: "
pause

:TFigLoop
IF ($TFigs = "N")
     send "PY"
     goto :StartScript
END
getWord CURRENTLINE $enemyfigs 6
getWord CURRENTLINE $yourfigs 3
stripText $enemyfigs ","
stripText $yourfigs ","
IF ($enemyfigs > $MaxTFigs)
     send "R"
     echo ANSI_10 "*Too many figs for current setting. Retreating*"
     goto :StartScript
ELSEIF ($enemyfigs > $yourfigs)
     send "R"
     echo ANSI_10 "*They have more figs then you. Retreating*"
     goto :StartScript
ELSE
send "A"
waitFor "Option? ("
send "9999*"
goto :TFigs
END



:FigsGone
goto :StartScript

:StopPrompt
send "*"
killTrigger 4
setTextTrigger 4 :StopPrompt "Stop in this sector"
pause

:Mines
send "N"
killTrigger 5
setTextTrigger 5 :Mines "Mined Sector:"
pause
