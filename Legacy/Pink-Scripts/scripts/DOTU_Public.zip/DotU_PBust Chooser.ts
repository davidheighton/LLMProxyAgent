#Script Author: Voltron
#Noted Bugs: Gets stuck if no planets in sector after it auto refurbs
#Future Plans: Add auto-refurb as option. Maybe even twarp

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Planet Bust Chooser " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "PBust's until specifed planet is made then prompts to name it"
echo ANSI_10 "*Date Made: " ANSI_13 "12/16/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Command of target sector"
echo ANSI_10 "*Special Notes: " ANSI_13 "Sometimes planet list gets messed up, just stop it and retry. Menu of planets over 7-8 items gets messed up sometimes.*"

# check if we can run it from here
cutText CURRENTLINE $location 1 7

IF ($location <> "Command")
        clientMessage "This script must be run from the game command menu"
        HALT
END

#Sets the var's to N/A to be used in displayin menu
:GetPlanetTypes
send "CJ?"
setVar $ClassH "N/A"
setVar $ClassNameH " "
setVar $ClassI "N/A"
setVar $ClassNameI " "
setVar $ClassJ "N/A"
setVar $ClassNameJ " "
setVar $ClassK "N/A"
setVar $ClassNameK " "
setVar $ClassL "N/A"
setVar $ClassNameL " "
setVar $ClassM "N/A"
setVar $ClassNameM " "
setVar $ClassN "N/A"
setVar $ClassNameN " "
setVar $ClassO "N/A"
setVar $ClassNameO " "
setVar $ClassP "N/A"
setVar $ClassNameP " "
setVar $ClassR "N/A"
setVar $ClassNameR " "
setVar $ClassS "N/A"
setVar $ClassNameS " "
setVar $ClassT "N/A"
setVar $ClassNameT " "
setVar $ClassU "N/A"
setVar $ClassNameU " "
setVar $ClassV "N/A"
setVar $ClassNameV " "
setVar $ClassW "N/A"
setVar $ClassNameW " "
setVar $ClassX "N/A"
setVar $ClassNameX " "
setVar $ClassY "N/A"
setVar $ClassNameY " "
setVar $ClassZ "N/A"
setVar $ClassNameZ " "

#Make our Triggers for each planet
setTextTrigger A :PlanetA "<A>"
setTextTrigger B :PlanetB "<B>"
setTextTrigger C :PlanetC "<C>"
setTextTrigger D :PlanetD "<D>"
setTextTrigger E :PlanetE "<E>"
setTextTrigger F :PlanetF "<F>"
setTextTrigger G :PlanetG "<G>"
setTextTrigger H :PlanetH "<H>"
setTextTrigger I :PlanetI "<I>"
setTextTrigger J :PlanetJ "<J>"
setTextTrigger K :PlanetK "<K>"
setTextTrigger L :PlanetL "<L>"
setTextTrigger M :PlanetM "<M>"
setTextTrigger N :PlanetN "<N>"
setTextTrigger O :PlanetO "<O>"
setTextTrigger P :PlanetP "<P>"
setTextTrigger Q :GetPlanetTypeQuit "<Q>"
setTextTrigger R :PlanetR "<R>"
setTextTrigger S :PlanetS "<S>"
setTextTrigger T :PlanetT "<T>"
setTextTrigger U :PlanetU "<U>"
setTextTrigger V :PlanetV "<V>"
setTextTrigger W :PlanetW "<W>"
setTextTrigger X :PlanetX "<X>"
setTextTrigger Y :PlanetY "<Y>"
setTextTrigger Z :PlanetZ "<Z>"
pause

#Stores the Planet class type and names
:PlanetA
setVar $line CURRENTLINE
getWord $line $ClassA 3
getWord $line $ClassNameA 4
getWordPos $line $WordPos $ClassNameA
cutText $line $ClassNameA $WordPos 50
pause
:PlanetB
setVar $line CURRENTLINE
getWord $line $ClassB 3
getWord $line $ClassNameB 4
getWordPos $line $WordPos $ClassNameB
cutText $line $ClassNameB $WordPos 50
pause
:PlanetC
setVar $line CURRENTLINE
getWord $line $ClassC 3
getWord $line $ClassNameC 4
getWordPos $line $WordPos $ClassNameC
cutText $line $ClassNameC $WordPos 50
pause
:PlanetD
setVar $line CURRENTLINE
getWord $line $ClassD 3
getWord $line $ClassNameD 4
getWordPos $line $WordPos $ClassNameD
cutText $line $ClassNameD $WordPos 50
pause
:PlanetE
setVar $line CURRENTLINE
getWord $line $ClassE 3
getWord $line $ClassNameE 4
getWordPos $line $WordPos $ClassNameE
cutText $line $ClassNameE $WordPos 50
pause
:PlanetF
setVar $line CURRENTLINE
getWord $line $ClassF 3
getWord $line $ClassNameF 4
getWordPos $line $WordPos $ClassNameF
cutText $line $ClassNameF $WordPos 50
pause
:PlanetG
setVar $line CURRENTLINE
getWord $line $ClassG 3
getWord $line $ClassNameG 4
getWordPos $line $WordPos $ClassNameG
cutText $line $ClassNameG $WordPos 50
pause
:PlanetH
setVar $line CURRENTLINE
getWord $line $ClassH 3
getWord $line $ClassNameH 4
getWordPos $line $WordPos $ClassNameH
cutText $line $ClassNameH $WordPos 50
pause
:PlanetI
setVar $line CURRENTLINE
getWord $line $ClassI 3
getWord $line $ClassNameI 4
getWordPos $line $WordPos $ClassNameI
cutText $line $ClassNameI $WordPos 50
pause
:PlanetJ
setVar $line CURRENTLINE
getWord $line $ClassJ 3
getWord $line $ClassNameJ 4
getWordPos $line $WordPos $ClassNameJ
cutText $line $ClassNameJ $WordPos 50
pause
:PlanetK
setVar $line CURRENTLINE
getWord $line $ClassK 3
getWord $line $ClassNameK 4
getWordPos $line $WordPos $ClassNameK
cutText $line $ClassNameK $WordPos 50
pause
:PlanetL
setVar $line CURRENTLINE
getWord $line $ClassL 3
getWord $line $ClassNameL 4
getWordPos $line $WordPos $ClassNameL
cutText $line $ClassNameL $WordPos 50
pause
:PlanetM
setVar $line CURRENTLINE
getWord $line $ClassM 3
getWord $line $ClassNameM 4
getWordPos $line $WordPos $ClassNameM
cutText $line $ClassNameM $WordPos 50
pause
:PlanetN
setVar $line CURRENTLINE
getWord $line $ClassN 3
getWord $line $ClassNameN 4
getWordPos $line $WordPos $ClassNameN
cutText $line $ClassNameN $WordPos 50
pause
:PlanetO
setVar $line CURRENTLINE
getWord $line $ClassO 3
getWord $line $ClassNameO 4
getWordPos $line $WordPos $ClassNameO
cutText $line $ClassNameO $WordPos 50
pause
:PlanetP
setVar $line CURRENTLINE
getWord $line $ClassP 3
getWord $line $ClassNameP 4
getWordPos $line $WordPos $ClassNameP
cutText $line $ClassNameP $WordPos 50
pause
:PlanetR
setVar $line CURRENTLINE
getWord $line $ClassR 3
getWord $line $ClassNameR 4
getWordPos $line $WordPos $ClassNameR
cutText $line $ClassNameR $WordPos 50
pause
:PlanetS
setVar $line CURRENTLINE
getWord $line $ClassS 3
getWord $line $ClassNameS 4
getWordPos $line $WordPos $ClassNameS
cutText $line $ClassNameS $WordPos 50
pause
:PlanetT
setVar $line CURRENTLINE
getWord $line $ClassT 3
getWord $line $ClassNameT 4
getWordPos $line $WordPos $ClassNameT
cutText $line $ClassNameT $WordPos 50
pause
:PlanetU
setVar $line CURRENTLINE
getWord $line $ClassU 3
getWord $line $ClassNameU 4
getWordPos $line $WordPos $ClassNameU
cutText $line $ClassNameU $WordPos 50
pause
:PlanetV
setVar $line CURRENTLINE
getWord $line $ClassV 3
getWord $line $ClassNameV 4
getWordPos $line $WordPos $ClassNameV
cutText $line $ClassNameV $WordPos 50
pause
:PlanetW
setVar $line CURRENTLINE
getWord $line $ClassW 3
getWord $line $ClassNameW 4
getWordPos $line $WordPos $ClassNameW
cutText $line $ClassNameW $WordPos 50
pause
:PlanetX
setVar $line CURRENTLINE
getWord $line $ClassX 3
getWord $line $ClassNameX 4
getWordPos $line $WordPos $ClassNameX
cutText $line $ClassNameX $WordPos 50
pause
:PlanetY
setVar $line CURRENTLINE
getWord $line $ClassY 3
getWord $line $ClassNameY 4
getWordPos $line $WordPos $ClassNameY
cutText $line $ClassNameY $WordPos 50
pause
:PlanetZ
setVar $line CURRENTLINE
getWord $line $ClassZ 3
getWord $line $ClassNameZ 4
getWordPos $line $WordPos $ClassNameZ
cutText $line $ClassNameZ $WordPos 50
pause

:GetPlanetTypeQuit
KillAllTriggers

#Get Current Sector and store it
send "QQ"
send "D"
setTextLineTrigger GetCurSec :getCurSector "Sector  : "
pause
:getCurSector
getWord CURRENTLINE $cursec 3
setVar $thisSector $cursec

#Show script banner
echo "**" ANSI_3 "     --" ANSI_11 "===| " ANSI_14 "Planet Chooser v2.0" ANSI_11 " |===" ANSI_3 "--*"
echo "**" ANSI_15 "By Voltron"
echo "**" ANSI_15 "Busts planets planets until you get the one you want."
echo "*" ANSI_15 "Assumes SD is not hidden. Also make's trips to SD, make sure its clear path"

#Display menu
:PickPlanetClass
echo "*" ANSI_15 "Select Planet Wanted:" "**"
echo ANSI_11 "<1> " ANSI_3 $ClassA & " " & $ClassNameA & "*"
echo ANSI_11 "<2> " ANSI_3 $ClassB & " " & $ClassNameB & "*"
echo ANSI_11 "<3> " ANSI_3 $ClassC & " " & $ClassNameC & "*"
echo ANSI_11 "<4> " ANSI_3 $ClassD & " " & $ClassNameD & "*"
echo ANSI_11 "<5> " ANSI_3 $ClassE & " " & $ClassNameE & "*"
echo ANSI_11 "<6> " ANSI_3 $ClassF & " " & $ClassNameF & "*"
echo ANSI_11 "<7> " ANSI_3 $ClassG & " " & $ClassNameG & "*"
IF ($ClassH <> "N/A")
     echo ANSI_11 "<8> " ANSI_3 $ClassH & " " & $ClassNameH & "*"
ELSEIF ($ClassI <> "N/A")
     echo ANSI_11 "<9> " ANSI_3 $ClassI & " " & $ClassNameI & "*"
ELSEIF ($ClassJ = "N/A")
     echo ANSI_11 "<0> " ANSI_3 $ClassJ & " " & $ClassNameJ & "*"
ELSEIF ($ClassK = "N/A")
     echo ANSI_11 "<-> " ANSI_3 $ClassK & " " & $ClassNameK & "*"
ELSEIF ($ClassL = "N/A")
     echo ANSI_11 "<=> " ANSI_3 $ClassL & " " & $ClassNameL & "*"
ELSEIF ($ClassM = "N/A")
     echo ANSI_11 "<W> " ANSI_3 $ClassM & " " & $ClassNameM & "*"
ELSEIF ($ClassN = "N/A")
     echo ANSI_11 "<E> " ANSI_3 $ClassN & " " & $ClassNameN & "*"
ELSEIF ($ClassO = "N/A")
     echo ANSI_11 "<R> " ANSI_3 $ClassO & " " & $ClassNameO & "*"
ELSEIF ($ClassP = "N/A")
     echo ANSI_11 "<T> " ANSI_3 $ClassP & " " & $ClassNameP & "*"
ELSEIF ($ClassR = "N/A")
     echo ANSI_11 "<Y> " ANSI_3 $ClassR & " " & $ClassNameR & "*"
ELSEIF ($ClassS = "N/A")
     echo ANSI_11 "<U> " ANSI_3 $ClassS & " " & $ClassNameS & "*"
ELSEIF ($ClassT = "N/A")
     echo ANSI_11 "<I> " ANSI_3 $ClassT & " " & $ClassNameT & "*"
ELSEIF ($ClassU = "N/A")
     echo ANSI_11 "<O> " ANSI_3 $ClassU & " " & $ClassNameU & "*"
ELSEIF ($ClassV = "N/A")
     echo ANSI_11 "<P> " ANSI_3 $ClassV & " " & $ClassNameV & "*"
ELSEIF ($ClassW = "N/A")
     echo ANSI_11 "<A> " ANSI_3 $ClassW & " " & $ClassNameW & "*"
ELSEIF ($ClassX = "N/A")
     echo ANSI_11 "<S> " ANSI_3 $ClassX & " " & $ClassNameX & "*"
ELSEIF ($ClassY = "N/A")
     echo ANSI_11 "<D> " ANSI_3 $ClassY & " " & $ClassNameY & "*"
ELSEIF ($ClassZ = "N/A")
     echo ANSI_11 "<F> " ANSI_3 $ClassZ & " " & $ClassNameZ & "*"
END
:PickPlanetClassEnd
getConsoleInput $PlanetClass SINGLEKEY

IF ($PlanetClass = 1)
     setVar $PlanetName $ClassA
ELSEIF ($PlanetClass = 2)
     setVar $PlanetName $ClassB
ELSEIF ($PlanetClass = 3)
     setVar $PlanetName $ClassC
ELSEIF ($PlanetClass = 4)
     setVar $PlanetName $ClassD
ELSEIF ($PlanetClass = 5)
     setVar $PlanetName $ClassE
ELSEIF ($PlanetClass = 6)
     setVar $PlanetName $ClassF
ELSEIF ($PlanetClass = 7)
     setVar $PlanetName $ClassG
ELSEIF ($PlanetClass = 8)
     setVar $PlanetName $ClassH
ELSEIF ($PlanetClass = 9)
     setVar $PlanetName $ClassI
ELSEIF ($PlanetClass = 0)
     setVar $PlanetName $ClassJ
ELSEIF ($PlanetClass = "-")
     setVar $PlanetName $ClassK
ELSEIF ($PlanetClass = "=")
     setVar $PlanetName $ClassL
ELSEIF ($PlanetClass = "W")
     setVar $PlanetName $ClassM
ELSEIF ($PlanetClass = "E")
     setVar $PlanetName $ClassN
ELSEIF ($PlanetClass = "R")
     setVar $PlanetName $ClassO
ELSEIF ($PlanetClass = "T")
     setVar $PlanetName $ClassP
ELSEIF ($PlanetClass = "Y")
     setVar $PlanetName $ClassR
ELSEIF ($PlanetClass = "U")
     setVar $PlanetName $ClassS
ELSEIF ($PlanetClass = "I")
     setVar $PlanetName $ClassT
ELSEIF ($PlanetClass = "O")
     setVar $PlanetName $ClassU
ELSEIF ($PlanetClass = "P")
     setVar $PlanetName $ClassV
ELSEIF ($PlanetClass = "A")
     setVar $PlanetName $ClassW
ELSEIF ($PlanetClass = "S")
     setVar $PlanetName $ClassX
ELSEIF ($PlanetClass = "D")
     setVar $PlanetName $ClassY
ELSEIF ($PlanetClass = "F")
     setVar $PlanetName $ClassZ
ELSE
     goto :PickPlanetClassEnd
END

window PBustChoose 175 75 "PBust Chooser" onTop
setWindowContents PBustChoose "Op: Creating" & "*Class: " & $PlanetName & "*Name: "


#############
:sub_MakePlanet
        killAllTriggers
        send "U"
        setTextTrigger 2 :sub_Go "Do you wish to launch one (Y/N) [N]?"
        setTextTrigger 5 :sub_RestockGtorps "You don't have any Genesis Torpedoes to launch!"
        pause

:sub_Go
        send "Y"
        setTextTrigger 3 :GetPlanetClass "(Class"
        setTextTrigger 4 :CorporatePlanet "(C)orporate"
        setTextTrigger 7 :sub_Blow "Command [TL="
        pause

        :GetPlanetClass
        setVar $line CURRENTLINE
        getWord $line $PlanetClass 10
        IF ($PlanetClass = $PlanetName)
             echo ANSI_10 "* A " $PlanetName " planet has been made, now just name it*"
             HALT
        END
        send "Voltron's PBust Script*"
        pause

        :CorporatePlanet
        send "C"
        pause

#Gotta quit to take off from planet        
:sub_RestockDets
        killAllTriggers
        send "QQ"
#Assumed at command prompt, and heads to SD
:sub_RestockGTorps
        killAllTriggers
        send "NSE"
        waitFor "Command [TL="
        send "PSH"
        setTextTrigger GetCash :GetCash "credits."
        pause
        :GetCash
        getWord CURRENTLINE $cash 3
        stripText $cash ","
        IF ($cash < 50000)
                echo ANSI_9 "**Too little of cash to continue**"
                send "QQ"
                HALT
        END
        #Get max GTorps we can buy
        send "T"
        setTextTrigger getGtorps :getGTorps "How many Genesis Torpedoes do you want"
        pause
        :getGTorps
        killTrigger getGtorps
        getWord CURRENTLINE $maxgtorps 9
        stripText $maxgtorps ")"
        send $maxgtorps "*a"
        setTextTrigger getDets :getDets "How many Atomic Detonators do you want"
        pause
        :getDets
        killTrigger getDets
        getWord CURRENTLINE $maxdets 9
        stripText $maxdets ")"
        send $maxdets "*"
        #We have our Gtorps and Dets, so lets leave SD and head back to home sector
        send "QQ"
        send "M" $cursec "*E"
        waitFor "Command [TL="
        goto :sub_Blow

:sub_Blow
        send "L"
        #Find the planet we just created
        :GetPlanetNumStart
        setTextTrigger GetPlanetNum :GetPlanetNum "< "
        pause
        :GetPlanetNum
        killTrigger GetPlanetNum
        setVar $line CURRENTLINE
        getWord $line $PlanetNum 2
        stripText $PlanetNum ">"
        getWordPos $line $TempPlanetName "Voltron's PBust Script"
        IF ($TempPlanetName = 0)
                goto :GetPlanetNumStart
        ELSE
                send $PlanetNum "*"
                #Blow it up :D
                send "ZDY"
                setTextTrigger 6 :sub_RestockDets "You do not have any Atomic Detonators!"
                setTextTrigger 7 :sub_MakePlanet "Command [TL="
                pause        
        END

        send "Q"
        goto :sub_MakePlanet