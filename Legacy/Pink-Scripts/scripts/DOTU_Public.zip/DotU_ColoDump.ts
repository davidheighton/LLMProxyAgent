#Script Author: Voltron
#Noted Bugs: Craps out if u dont own planet and has lvl 2 or higher cit, or Enemy owner is in sec with u when u try to land. 
#Future Plans: Possibly make a Mass_ColoDump. Dumps all planets in sec

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Colonist Massacre(Dump) 2.0" ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: Dumps all colos in chosen group"
echo ANSI_10 "*Date Made: " ANSI_13 "11/03/01 "
echo ANSI_10 "*Start Point: Planet command"
echo ANSI_10 "*Special Notes: Make sure you own the planet *"

# check if we can run it from here
cutText CURRENTLINE $location 1 14

IF ($location <> "Planet command")
        clientMessage "This script must be run from the surface of a planet"
        HALT
END

LOGGING OFF

:GetColosFrom
echo "*" ANSI_15 "Select which category to dump colos from:" "**"
echo ANSI_11 "1 " ANSI_3 " - Fuel Ore*"
echo ANSI_11 "2 " ANSI_3 " - Organics*"
echo ANSI_11 "3 " ANSI_3 " - Equipment*"
echo ANSI_11 "4 " ANSI_3 " - All*"
getConsoleInput $ColosFrom SINGLEKEY

IF ($ColosFrom = 1)
     setVar $ColoGroup 1
ELSEIF ($ColosFrom = 2)
     setVar $ColoGroup 2
ELSEIF ($ColosFrom = 3)
     setVar $ColoGroup 3
ELSEIF ($ColosFrom = 4)
     setVar $ColoGroup 4
ELSE
     goto :GetColosFrom
END

#getinput $quantity "Enter # of Colos to dump" 0

# Set trigger to stop script if disconnected
setEventTrigger 0 :End "Connection lost"

# get the planet number for the planet we're on
send "d"
setTextLineTrigger 1 :getPlanet "Planet #"
pause
:getPlanet
getWord CURRENTLINE $planet 2
stripText $planet "#"
killTrigger 1

window DumpColo 140 75 "Colo Dump" onTop
setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & "*Category: "
send "qjy"

:sub_Land
send "l" $planet "*"
setTextTrigger 2 :getHolds " free cargo holds."
setTextTrigger 3 :GetFuelColos "Fuel Ore  "
setTextTrigger 4 :GetOrgColos "Organics  "
setTextTrigger 5 :GetEquColos "Equipment  "
pause

:GetFuelColos
getWord CURRENTLINE $FuelColos 3
stripText $FuelColos ","
killTrigger 3
pause

:GetOrgColos
getWord CURRENTLINE $OrgColos 2
stripText $OrgColos ","
killTrigger 4
pause

:GetEquColos
getWord CURRENTLINE $EquColos 2
stripText $EquColos ","
killTrigger 5
pause

:getHolds
killTrigger 2
getWord CURRENTLINE $holds 3
IF ($holds = 0)
        clientMessage "No free cargo holds!"
        HALT
END

waitFor "Planet command (?=help) [D]"

:Sub_Dump
     killAllTriggers
     IF ($ColosFrom = 1)
          setVar $Product "Fuel"
          send "s*t1"
          IF ($holds > $FuelColos)
               send $FuelColos "*"
               setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $FuelColos & "*Category: " & $Product
               send "qjy"
               halt
          ELSE
               send "*"
               setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $FuelColos & "*Category: " & $Product
               send "qjy"
               subtract $FuelColos $holds
          END
     END

     IF ($ColosFrom = 2)
          setVar $Product "Org"
          send "s*t2"
          IF ($holds > $OrgColos)
               send $OrgColos "*"
               setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $OrgColos & "*Category: " & $Product
               send "qjy"
               halt
          ELSE
               send "*"
               setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $OrgColos & "*Category: " & $Product
               send "qjy"
               subtract $OrgColos $holds
          END
     END

     IF ($ColosFrom = 3)
          setVar $Product "Equip"
          send "s*t3"
          IF ($holds > $EquColos)
               send $EquColos "*"
               setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $EquColos & "*Category: " & $Product
               send "qjy"
               halt
          ELSE
               send "*"
               setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $EquColos & "*Category: " & $Product
               send "qjy"
               subtract $EquColos $holds
          END
     END

     IF ($ColosFrom = 4)
          IF ($FuelColos > 0)
               setVar $Product "All: Fuel"
               send "s*t1"
               IF ($holds < $FuelColos)
                    send "*"
                    setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $FuelColos & "*Category: " & $Product
                    send "qjy"
                    subtract $FuelColos $holds
                    goto :sub_Done
               ELSE
                    send $FuelColos "*"
                    setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $FuelColos & "*Category: " & $Product
                    send "qjy"
                    goto :sub_Done
               END
          ELSEIF ($OrgColos > 0)
               setVar $Product "All: Org"
               send "s*t2"
               IF ($holds < $OrgColos)
                    send "*"
                    setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $OrgColos & "*Category: " & $Product
                    send "qjy"
                    subtract $OrgColos $holds
                    goto :sub_Done
               ELSE
                    send $OrgColos "*"
                    setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $OrgColos & "*Category: " & $Product
                    send "qjy"
                    goto :sub_Done
               END
          ELSEIF ($EquColos > 0)
               setVar $Product "All: Equip"
               send "s*t3"
                    IF ($holds < $EquColos)
                    send "*"
                    setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $EquColos & "*Category: " & $Product
                    send "qjy"
                    subtract $EquColos $holds
                    goto :sub_Done
               ELSE
                    send $EquColos "*"
                    setWindowContents DumpColo "Dumping Planet: " & $planet & "*Colo's left: " & $EquColos & "*Category: " & $Product
                    send "qjy"
                    goto :sub_Done
               END
          END
          send "Q"
          HALT
     END

:sub_Done
killAllTriggers
goto :sub_Land


