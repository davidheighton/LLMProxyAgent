#Script Author: Voltron
#Noted Bugs: None
#Future Plans: Add support for planets

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Search Script " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Search TWX database for constellations, port names, or beacons found"
echo ANSI_10 "*Date Made: " ANSI_13 "12/1/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Anywhere"
echo ANSI_10 "*Special Notes: " ANSI_13 "CASE-senstive and can use parts of words/letters. Only searches thru explored sectors. Uses 97% CPU power and cant be stopped midway. Just be forwarned*"

setVar $MaxSectors SECTORS

#Display Main Menu
:SearchMenu
echo ANSI_10 "**Pick Search Category"
echo ANSI_12 "*<" ANSI_9 "1" ANSI_12 "> Space Name (constellation)"
echo ANSI_12 "*<" ANSI_9 "2" ANSI_12 "> Port Name"
echo ANSI_12 "*<" ANSI_9 "3" ANSI_12 "> Beacon Name"
echo ANSI_12 "*<" ANSI_9 "Q" ANSI_12 "> Quit"
getConsoleInput $MenuChoice SINGLEKEY
if ($MenuChoice = 1) 
        goto :SpaceSearchMenu
elseif ($MenuChoice = 2)
        goto :PortSearchMenu
elseif ($MenuChoice = 3)
        goto :BeaconSearchMenu
elseif ($MenuChoice = "Q")
        halt
else
        goto :SearchMenu
end

#Display Menu to search for space (constellations)
:SpaceSearchMenu
echo ANSI_10 "**Which type of Space do you want to find?"
echo ANSI_12 "*<" ANSI_9 "1" ANSI_12 "> The Federation."
echo ANSI_12 "*<" ANSI_9 "2" ANSI_12 "> Ferrengi Space."
echo ANSI_12 "*<" ANSI_9 "3" ANSI_12 "> User Defined Search"
echo ANSI_12 "*<" ANSI_9 "B" ANSI_12 "> Go Back"
echo ANSI_12 "*<" ANSI_9 "Q" ANSI_12 "> Quit"
getConsoleInput $MenuChoice SINGLEKEY
if ($MenuChoice = 1) 
        setVar $Space "The Federation."
elseif ($MenuChoice = 2)
        setVar $Space "Ferrengi Space."
elseif ($MenuChoice = 3)
        getInput $Space "Enter name of space or word contained in it"
elseif ($MenuChoice = "B")
        goto :SearchMenu
elseif ($MenuChoice = "Q")
        halt
else
        goto :SpaceSearchMenu
end

echo ANSI_10 "**Search commencing, please wait!!*"
window WinSearch 140 90 "Search Script" OnTop

:SpaceSearch
setWindowContents WinSearch "Op: Space Search *Max Sectors: " & $MaxSectors & "*Current Sector: " & $i
add $i 1
if ($i > $MaxSectors)
        echo ANSI_10 "**Search is complete, all found sectors displayed*"
        halt
end
getSector $i $sector
getWordPos $sector.constellation $result $Space
IF ($result <> 0)
        echo ANSI_12 "*" 
        echoChar 180 
        echo ANSI_9 $sector.constellation ANSI_12 
        echoChar 195
        echo " found in sector " ANSI_9
        echoChar 174
        echo ANSI_10 $i ANSI_9
        echoChar 175 
END
goto :SpaceSearch

#Display Menu to search for Port Name
:PortSearchMenu
echo ANSI_10 "**Which port name you wanna find?"
echo ANSI_12 "*<" ANSI_9 "1" ANSI_12 "> Stargate Alpha I"
echo ANSI_12 "*<" ANSI_9 "2" ANSI_12 "> Sol"
echo ANSI_12 "*<" ANSI_9 "3" ANSI_12 "> Rylos"
echo ANSI_12 "*<" ANSI_9 "4" ANSI_12 "> Alpha Centauri"
echo ANSI_12 "*<" ANSI_9 "5" ANSI_12 "> User Defined"
echo ANSI_12 "*<" ANSI_9 "B" ANSI_12 "> Go Back"
echo ANSI_12 "*<" ANSI_9 "Q" ANSI_12 "> Quit*"
getConsoleInput $MenuChoice SINGLEKEY
if ($MenuChoice = 1) 
        setVar $PortName "Stargate Alpha I"
elseif ($MenuChoice = 2)
        setVar $PortName "Sol"
elseif ($MenuChoice = 3)
        setVar $PortName "Rylos"
elseif ($MenuChoice = 4)
        setVar $PortName "Alpha Centauri"
elseif ($MenuChoice = 5)
        getInput $PortName "Enter name of Port or substring"
elseif ($MenuChoice = "B")
        goto :SearchMenu
elseif ($MenuChoice = "Q")
        halt
else
        goto :PortSearchMenu
end

window WinSearch 140 90 "Search Script" OnTop
echo ANSI_10 "**Search commencing, please wait!!*"

:PortSearch
setWindowContents WinSearch "Op: Portname Search *Max Sectors: " & $MaxSectors & "*Current Sector: " & $i
add $i 1
if ($i > $MaxSectors)
        echo ANSI_10 "**Search is complete, all found sectors displayed*"
        halt
end
getSector $i $sector
getWordPos $sector.port.name $result $PortName
if ($result <> 0)
        echo ANSI_12 "*" 
        echoChar 180 
        echo ANSI_9 $sector.port.name ANSI_12 
        echoChar 195
        echo " found in sector " ANSI_9
        echoChar 174
        echo ANSI_10 $i ANSI_9
        echoChar 175 
end
goto :PortSearch

#Display Menu to search for beacon name
:BeaconSearchMenu
echo ANSI_10 "**Enter name of Beacon to find"
echo ANSI_12 "*<" ANSI_9 "1" ANSI_12 "> User Defined Search"
echo ANSI_12 "*<" ANSI_9 "B" ANSI_12 "> Go Back"
echo ANSI_12 "*<" ANSI_9 "Q" ANSI_12 "> Quit"
getConsoleInput $MenuChoice SINGLEKEY
if ($MenuChoice = 1) 
        getInput $Beacon "Enter name of beacon or substring (Do just a space for all beacons)" 
elseif ($MenuChoice = "B")
        goto :SearchMenu
elseif ($MenuChoice = "Q")
        halt
else
        goto :BeaconSearchMenu
end

echo ANSI_10 "**Search commencing, please wait!!*"
window WinSearch 140 90 "Search Script" OnTop

:BeaconSearch
setWindowContents WinSearch "Op: Beacon Search *Max Sectors: " & $MaxSectors & "*Current Sector: " & $i
add $i 1
if ($i > $MaxSectors)
        echo ANSI_10 "**Search is complete, all found sectors displayed*"
        halt
end
getSector $i $sector
getWordPos $sector.beacon $result $Beacon
if ($result <> 0)
        echo ANSI_12 "*" 
        echoChar 180 
        echo ANSI_9 $sector.beacon ANSI_12 
        echoChar 195
        echo " found in sector " ANSI_9
        echoChar 174
        echo ANSI_10 $i ANSI_9
        echoChar 175 
end
goto :BeaconSearch
