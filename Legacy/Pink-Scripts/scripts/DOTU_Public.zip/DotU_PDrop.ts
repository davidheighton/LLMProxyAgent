#Script Author: Voltron
#Noted Bugs: None
#Future Plans: Friend/Foe list. Add return to home option and auto attacking. Maybe ptorp'n also

echo ANSI_12 "**                ���" ANSI_10 "�" ANSI_13 " DotU:" ANSI_9 " Planet Drop " ANSI_10 "�" ANSI_12 "���*"
echo ANSI_10 "*Description: " ANSI_13 "Rains fury from above with lvl 4 or higher planets. Watch enemy hit fig and away u go."
echo ANSI_10 "*Date Made: " ANSI_13 "11/10/01"
echo ANSI_10 "*Start Point: " ANSI_13 "Citadel prompt"
echo ANSI_10 "*Special Notes: " ANSI_13 "Make sure cannon lvls and IC are all set properly and you have plenty of fuel. Pops up large window when u pdrop if u not watchin console. Idea from Reverend, but his REXX wasnt working.*"


# check to make sure we in a citadel
cutText CURRENTLINE $location 1 15
if ($location <> "Citadel command")
        echo "**" ANSI_12 "WARNING: You must be in a citadel first!"
        halt
end

:Start
send "P"
:Start2
killAllTriggers

setTextLineTrigger timeout :Timeout "will be terminated in"
setTextLineTrigger fig :Fig "Deployed Fighters"
pause

#Anti-idle function. Keeps you online for those times when u can't wait for enemy to come out and play >:)
:Timeout
send "#"
killTrigger timeout
setTextLineTrigger timeout :Timeout "will be terminated in"
pause

:Fig
setVar $line CURRENTLINE
getWord CURRENTLINE $chk 1
getWord CURRENTLINE $sector 5
getWord CURRENTLINE $enemy 6
IF ($chk = "F") OR ($chk = "R") OR ($chk = "P")
        goto :Start2
END

#*****************This section was for a custom game with aliens. Replace them with name of alien race or friends if u wish to use also
#IF ($enemy = "Serri") OR ($enemy = "Raiders") OR ($enemy = "TUROK's") OR ($enemy = "Loki's")
#        goto :Start2
#END
stripText $sector ":"
killTrigger fig
goto :Sub_pdrop

:Sub_pdrop
send $sector "*"
setTextTrigger locked :Locked "All Systems Ready"
setTextTrigger blind :Start "Blind Jump"
setTextTrigger nofuel :NoFuel "You do not have enough Fuel Ore"
pause

:Locked
send "Y"
ECHO ANSI_10 "**P-Drop successful**"
window PDrop 500 500 "PDrop Successful" OnTop
setDelayTrigger Success :Success 60000
pause
:Success
HALT

:NoFuel
echo "*Not enough fuel for that pdrop, resetting automatically"
goto :Start