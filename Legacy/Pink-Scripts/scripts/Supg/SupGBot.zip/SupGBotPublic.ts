# TWX SupG Script  : SupGBotPublic
# Author           : SupG
# Description      : Remote Control bot that allows your corpies to control
#                    certain aspects of the game while you're away
# Trigger Point    : Command prompt
# Warnings         : Be sure you only give access to the bot to people you 
#		     trust.  The bot has security levels 1-9, 9 being bot owner status
#		     I recommend you give no one level 9 access.  The bot owner will automatically
#		     have level 9 access.  This is a limited version of my personal script so some
#		     security levels are not used.  Level 4 access allows the shooting of photons
#		     and level 6 access allows cim hunter to be activated. Name your bot something
#		     other than 'bot' to provide extra security for subspace sniffers wanting to get 
#		     control of your bot. 
#		     The people accessing your bot must not have any spaces within the first 6 letters
#		     of their names, they can be shorter than 6 characters, but they must not have spaces
#		     ie.. col sanders - does not work
#		     ie.. Emerald Dragon - does work
#		     When cim hunter is activated, it will check your cim data every 5 minutes, it's best
#		     if you only have cim hunter activated while you are AFK.
#		     You may access your own bot by typing into subspace ' botname command parameters
#		     making sure there is a space before the bot name.
#		     ie.. ' bot pw 122
#		     if you mess up typing your command
#		     you must delete the whole line and start over or your command won't work.
#		     as another security
# Other            : Let me know of any problems with this script
#www.twtavern.com


#Initializations  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
:getInitial_Settings
setVar $keepalive_ctr 0
setVar $config_file "scripts/supgbot/supgbot.cfg"
setVar $gconfig_file "scripts/supgbot/" & GAMENAME & ".bot"
setVar $cim_file "scripts/supgbot/" & GAMENAME & ".cim"
setVar $cim_temp "scripts/supgbot/cim.tmp"
setVar $init 1
fileExists $file_chk $config_file
fileExists $gfile_chk $gconfig_file
if ($file_chk = "FALSE")
	clientMessage "First time running SupGBot, you must add game."
	gosub :add_game
else
	setVar $config_info_counter 1
:getConfig_File_info
	read $config_file $config_info_line $config_info_counter
	if ($config_info_line <> "EOF") and ($gfile_chk = "TRUE")
		if ($config_info_line = GAMENAME)
			read $gconfig_file $bot_name 1
			goto :run_bot
		else
			add $config_info_counter 1
			goto :getConfig_file_info
		end
	else
:conf_bot	
		echo ANSI_15 "*This Game is not configured for SupGBot, doing this now.*"
		gosub :add_game
		goto :run_bot
	end	
end

#Wait for Commands =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
:run_bot
setVar $watch_status "INACTIVE"
setVar $cim_status "INACTIVE"
send "'SupGBot is Now running, type " $bot_name " ? for a list of commands*"
:initiate_bot
setDelayTrigger keepalive :keepalive 60000
#<><><>Main<><><>
:wait_for_command
killtrigger hehheh
gosub :reset_triggers
setVar $pdrop_act 0
if ($watch_status = "ACTIVE")
	setVar $trip_trigger_name "W"
elseif ($pdrop_status = "ACTIVE")
	setVar $trip_trigger_name "P"
end
if ($watch_status = "ACTIVE") or ($pdrop_status = "ACTIVE")
	setTextLineTrigger limpet :trip_limpet "Limpet mine in"
	setTextLineTrigger fighter :trip_fighter "Deployed Fighters Report Sector"
end
setTextLineTrigger got_command :command "R "
setTextLineTrigger own_command :command "' " & $bot_name
setTextLineTrigger hehheh :online_watch "Who's Playing"
pause



#Command Routing =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
:command
getWord CURRENTLINE $radio_type 1
if ($radio_type = "R")
	getWord CURRENTLINE $botname_chk 3
	if ($botname_chk <> $bot_name)
		goto :wait_for_command
	end
	getWord CURRENTLINE $user_name 2
	getWord CURRENTLINE $command 4
	getWord CURRENTLINE $parm1 5
	getWord CURRENTLINE $parm2 6
	striptext $command "^"
	upperCase $user_name
	gosub :verify_user_status
	if ($authorization = 0)
		goto :wait_for_command
 	end
elseif ($radio_type = "'")
	getWord CURRENTLINE $botname_chk 2
	if ($botname_chk <> $bot_name)
		goto :wait_for_command
	end
	setVar $user_name "Bot Owner"
	setVar $user_sec_level 9
	getWord CURRENTLINE $command 3
	getWord CURRENTLINE $parm1 4
	getWord CURRENTLINE $parm2 5
	striptext $command "^"
else
	goto :wait_for_command
end
lowerCase $command
lowerCase $parm1
lowerCase $parm2
if ($command = "blast")
	gosub :blast
elseif ($command = "land")
	setVar $planetnumber $parm1
	gosub :land
elseif ($command = "fire") and ($user_sec_level > 3)
	setVar $shoot_sector $parm1 
	if ($shoot_sector < 11) and ($shoot_sector > 0)
		send "'Cannot Fire Photons into Fed space, dummy.*"
		goto :wait_for_command
	end	
	gosub :fire_photon
elseif ($command = "watch")
	setVar $watch $parm1
	gosub :watch
elseif ($command = "pw")
	setVar $pwarp_sector $parm1
	gosub :warp_planet
elseif ($command = "status")
	gosub :status
elseif ($command = "scan")
	gosub :scanme
elseif ($command = "?")
	gosub :command_list
elseif ($command = "cim") and ($user_sec_level > 5)
	setVar $cim_select $parm1
	gosub :cim_hunt
elseif ($command = "adduser") and ($user_sec_level = 9)
	setVar $new_user_name $parm1
	setVar $new_user_sec_level $parm2
	gosub :add_user
elseif ($command = "page")
	gosub :page
elseif ($command = "kill")
	send "'Shutting Down...*"
	halt
else
	send "'Invalid Command.*"
end
goto :wait_for_command
halt
=-=-===-=-=-==-===-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#Add Game =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
:add_game
echo ANSI_15 "*What is the 'in game' name of the bot? (one word, no spaces)*"
getConsoleinput $new_bot_name
stripText $new_bot_name "^"
stripText $new_bot_name " "
:get_sd
lowerCase $new_bot_name
write $gconfig_file $new_bot_name
write $config_file GAMENAME
setVar $bot_name $new_bot_name
return 

#Security =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-
#User Verification
:verify_user_status
setVar $verify_cnt 2
:verify
read $gconfig_file $auth_user $verify_cnt
if ($auth_user <> "EOF")
	getWord $auth_user $auth_user_name 1
	if ($auth_user_name = $user_name)
		getWord $auth_user $user_sec_level 2
		setVar $authorization 1
		return
	else
		add $verify_cnt 1
		goto :verify
	end
else
	waitfor "(?="
	setVar $authorization 0
	return
end

#Add User
:add_user
stripText $new_user_name "^"
stripText $new_user_name "*"
cutText $new_user_name $new_user_name 1 6
stripText $new_user_name " "
uppercase $new_user_name
isNumber $result $new_user_sec_level
if ($result = "FALSE")
	send "'Invalid Security Level, User Not added.*"
	return
end
if ($new_user_sec_level > 9) or ($new_user_sec_level < 1)
	send "'Invalid Security Level, User Not added.*"
else
	write $gconfig_file $new_user_name & " " & $new_user_sec_level
	send "'User " $new_user_name " added with a " $new_user_sec_level " security level.*"
end
return

#Check Sectors Hit =--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#<><><> Hit a Limpet <><><>
:trip_limpet
gosub :reset_triggers
if ($trip_trigger_name = "W")
	getWord CURRENTLINE $hit_sector 4
	getWord CURRENTLINE $is_fedcom 1
	stripText $hit_sector ":"
	if ($is_fedcom <> "Limpet")
		goto :wait_for_command
	end
	getSector $current_sector $current_sector_info
	gosub :check_adj
	if ($adj = "YES")
		gosub :fire_photon
	end
else
	goto :wait_for_command
end
goto :wait_for_command

#<><><> Hit a Fighter <><><>
:trip_fighter
gosub :reset_triggers
getWord CURRENTLINE $hit_sector 5
getWord CURRENTLINE $is_fedcom 1
stripText $hit_sector ":"
if ($is_fedcom <> "Deployed")
	goto :wait_for_command
end
stripText $sectorNum ":"
if ($trip_trigger_name = "W")
	getSector $current_sector $current_sector_info
	gosub :check_adj
	if ($adj = "YES")
		gosub :fire_photon
	end
elseif ($trip_trigger_name = "P")
	setVar $pwarp_sector $hit_sector
	setVar $pdrop_act 1
	gosub :warp_planet
end
goto :wait_for_command

#Blast Command  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
:blast
waitfor "(?="
cutText CURRENTLINE $location 1 7
striptext $location " "
if ($location = "Citadel")
	send "'Blasting Off!*qq"
elseif ($location = "Command")
        send "'Not on a planet, type " $bot_name " land <planetnumber> - to land*"
elseif ($location = "Planet")
      	send "'Blasting Off!*q"
else
	send "'Could not blast off, invalid prompt.*"
end
return

#Planet Warp Sub =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=
:warp_planet
waitfor "(?="
cutText CURRENTLINE $prompt 1 7
striptext $prompt " "
if ($prompt <> "Citadel")
	send "'WARNING: Can not warp planet from current prompt!.*"
	return
end
isNumber $num_chk $pwarp_sector
if ($num_chk = "TRUE")
	send "p" $pwarp_sector "*y"
	setTextLineTrigger bjump :no_jump "You cannot"
	setTextLineTrigger jump_success :jump_success "Planet is now in sector"
	setTextLineTrigger in_sector_already :already_there "You are already in that sector!"
	setTextLineTrigger no_fuel :no_fuel "You do not have enough Fuel Ore"
	pause
else
	send "'Invalid Sector Number.*"
end

:jump_success
gosub :reset_triggers
send "'Planet now in " $pwarp_sector ".*"
if ($pdrop_act = 1)
	setVar $pdrop_act 0
	sound "scripts/supgbot/message.wav"
	setVar $pdrop_status "INACTIVE"
	send "'Pdrop now INACTIVE*"
end
return

:no_jump
gosub :reset_triggers
if ($pdrop_act = 1)
	setVar $pdrop_act 0
else
	send "'Cannot Blind Jump Planet. Lay a fig.*"
end
return

:already_there
gosub :reset_triggers
send "'Planet is already in that sector.*"
return	

:no_fuel
gosub :reset_triggers
send "'Planet does not have enough Fuel Ore to make jump.*"
return


#Fire Photon Sub =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
:fire_photon
waitFor "(?="
cutText CURRENTLINE $prompt 1 7
striptext $prompt " "
if ($prompt <> "Command") and ($prompt <> "Citadel")
	send "'WARNING: Can not fire photons from current prompt!.*"
	return
end
isNumber $num_chk $shoot_sector
if ($num_chk = "TRUE")
	send "cp"
	gosub :fire_checks	
	if ($ptorps  = 1)
		send "y" $shoot_sector "*q"
		gosub :fire_checks
		if ($ptorp_fired = 1)
			send "'Photoned " $shoot_sector ".*"
			sound "scripts/supgbot/message.wav"
		end
	end
else
	send "'Invalid Sector Number.*"
end
return

:fire_checks
settextlinetrigger no_torps :no_torps "You do not have any Photon Missiles!"
settexttrigger have_torps :have_torps "Do you wish to launch one ?"
settextlinetrigger ptorp_not_adj :ptorp_not_adj "That is not an adjacent sector"
settextlinetrigger ptorp_fired :ptorp_fired "Photon Missile launched"
pause

:no_torps
gosub :reset_triggers
send "'I have no photon missiles.*q"

setVar $ptorps 0
return

:have_torps
gosub :reset_triggers
setVar $ptorps 1
return

:ptorp_not_adj
gosub :reset_triggers
send "'Sector is not adjacent, could not fire photon*"
setVar $ptorp_fired 0
send "q"
return

:ptorp_fired
gosub :reset_triggers
setVar $ptorp_fired 1
return

#Check Adjacent sub =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
:check_adj
if ($adj_checker < $current_sector_info.warps)
	add $adj_checker 1
	if ($current_sector_info.warp[$adj_checker] = $hit_sector)
		setVar $shoot_sector $hit_sector
		setVar $adj "YES"
	else		
		setVar $adj "NO"
		goto :check_adj
	end
end
return

#Turn Cim Hunter on =-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
:cim_hunt
waitfor "(?="
if ($cim_select = "on")
	if ($cim_status = "ACTIVE")	
		send "'Cim Hunter is already enabled*"
	else
		send "'Cim Hunter is now ACTIVE*"
		setVar $cim_status "ACTIVE"
	end
	if ($watch_status = "ACTIVE")
		setVar $watch_status "INACTIVE"
		send "'Watch is now INACTIVE*"
	end
elseif ($cim_select = "off")
	send "'Cim Hunter is now INACTIVE.*"
	setVar $cim_status "INACTIVE"
else
	send "'Cim Hunter is currently " $cim_status "*"
end
return
#Turn Watch On  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
:watch
waitfor "(?="
if ($watch = "off")
	send "'Watch is now INACTIVE.*"
	setVar $watch_status "INACTIVE"
	return
end
cutText CURRENTLINE $prompt 1 8
striptext $prompt " "
if ($prompt = "Citadel")
	send "S"
elseif ($prompt = "Command")
	send "d"
else
	send "'Invalid Prompt, cannot enable Watch.*"
	return
end
waitfor "Sector  :"
getWord CURRENTLINE $current_sector 3
stripText $current_sector ":"
send "I"
setTextLineTrigger got_torps :got_em "Photon Missiles:"
waitfor "Credits"
gosub :reset_triggers
send "'No photons, cannot enable Watch.*"
return
:got_em
gosub :reset_triggers
if ($watch = "on")
	if ($cim_status = "ACTIVE")
		setVar $cim_status "INACTIVE"
		send "'Cim Hunter is now INACTIVE*"
	end
		send "'Watch is now ACTIVE : " $current_sector "*"
	setVar $watch_status "ACTIVE"
else
	send "'Watch is currently " $watch_status "*"
end
return

#Status Sub =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-
:status
waitfor "(?="
gosub :reset_triggers
settextlinetrigger stattorps :stattorps "Photon Missiles"
settextlinetrigger contstat :contstatus "Credits"
cutText CURRENTLINE $prompt 1 8
striptext $prompt " "
if ($prompt <> "Command") and ($prompt <> "Citadel") and ($prompt <> "Planet") and ($prompt <> "Computer")
	send "'Invalid Prompt, cannot give status.*"
	return
end
if ($prompt = "Planet")
	send "c"
end
if ($prompt = "Computer")
	send "q"
end
send "I"
waitfor "Sector"
getword CURRENTLINE $statsector 4
waitfor "Turns" 
getword CURRENTLINE $statturns 4
pause

:stat
goto :contstatus

:stattorps
getword CURRENTLINE $stattorps 3
goto :stat

:contstatus
send "'*"
send "Current Prompt : " $prompt "*"
send "Current Sector : " $statsector "*"
send "Turns Left     : " $statturns "*"
send "Photons Left   : " $stattorps "*"
send "Watch Status   : " $watch_status "*"
send "Cim Hunter     : " $cim_status "**"
if ($prompt = "Planet")
	send "q"
end
if ($prompt = "Computer")
	send "c"
end
return

#Keep Alive =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
:keepalive
add $keepalive_ctr 1
if ($cim_status = "ACTIVE") and ($keepalive_ctr > 4)
	setVar $keepalive_ctr 0
	gosub :cim_chk
end
send "#"
goto :initiate_bot

#Land Sub =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
:land
waitFor "(?="
cutText CURRENTLINE $location 1 7
striptext $location " "
if ($location <> "Command")
	if ($location = "Citadel") or ($location = "Planet")
        	send "'Already on a planet, type " $bot_name " blast - to blast me off*"
        else
        	send "'Could not land, invalid prompt.*"
	end
else
        isNumber $result $planetnumber
        if ($result = "FALSE")
 	      	send "'No planet number, please type: " $bot_name " land <planetnumber>.*"
        elseif ($planetnumber = "0")
               	send "'No planet number, please type: " $bot_name " land <planetnumber>.*"
	else
        	send "l" $planetnumber "*"
	        setTextLineTrigger not_here :not_here "That planet is not in this sector."
		setTextLineTrigger landing :landing "Landing sequence engaged..."
		pause
:landing
		gosub :reset_triggers
		send "c"
        	setTextLineTrigger no_cit :no_cit "This planet does not have a Citadel on it"
		setTextLineTrigger in_cit :in_cit "<Enter Citadel>"
		pause
:in_cit
		gosub :reset_triggers
		send "'On planet: #" $planetnumber " in the Citadel awaiting thy command!" "*"
        end
end
return

:not_here
gosub :reset_triggers
send "'That Planet is not in this sector*q*"
return

:no_cit
gosub :reset_triggers
send "'On planet: #" $planetnumber " awaiting thy command! (no citadel)" "*"
return

#Cim Hunter =-=-=-=-=-=-=-===-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
:cim_chk
fileExists $file_check $cim_file
if ($file_check = "FALSE")
	setVar $new_file 1
	goto :get_cim
end


:get_cim
	 setVar $colon 0
	 setVar $used_port_count 0
 	 setVar $Cim_file_place 1
	 send "^rq"
	waitfor ":"
	
:cim
	 setVar $spanky 0
	 setTextLineTrigger cim :cimmer
	 pause
:cimmer
 	setVar $info CURRENTLINE
	getWord $info $end_test 2
        getWord $info $colon 1
	if ($end_test = "ENDINTERROG")
		goto :done
	end
	if ($colon = ":")
		goto :cim
	end
	if ($new_file = 1)
        	stripText $info "-"
		write $cim_file $info
	 	goto :cim
	else
		stripText $info "-"
		write $cim_temp $info
:read_file
		read $cim_file $cim_info $cim_file_place
		setVar $sector_info 2
		if ($cim_info = "EOF")
			setVar $cim_info_sector 50000
		else
			getWord $cim_info $cim_info_sector 1
		end
		getWord $info $info_sector 1
		if ($cim_info_sector = $info_sector)
			if ($info_sector = 0)
				goto :done
			end
			getSector $info_sector $port_info
			getWord $cim_info $cim_info_fuel 3
			getWord $cim_info $cim_info_orgs 5
			getWord $cim_info $cim_info_equi 7
		        stripText $cim_info_fuel "%"
			stripText $cim_info_orgs "%"
			stripText $cim_info_equi "%"
			if ($cim_info_fuel > $port_info.port.PERC_ORE) or ($cim_info_orgs > $port_info.port.perc_org) or ($cim_info_equi > $port_info.port.perc_equip)
				add $used_port_count 1
				if ($cim_info_fuel > $port_info.port.PERC_ORE)
					setVar $fueldifference $cim_info_fuel
					subtract $fueldifference $port_info.port.perc_ore
					if ($fueldifference > 10)
						add $spanky 1
					end
				end
				if ($cim_info_orgs > $port_info.port.perc_org)
					setVar $orgsdifference  $cim_info_orgs
					subtract $orgsdifference $port_info.port.perc_org
					if ($orgsdifference > 10)
						add $spanky 2
					end
				end
				if ($cim_info_equi > $port_info.port.perc_equip)
					setVar $equidifference $cim_info_equi
					subtract $equidifference $port_info.port.perc_equip
					if ($equidifference > 10)
						add $spanky 4
					end
				end
				echo $spanky "*"
				if ($spanky = 1)
					setVar $change_port[$used_port_count] "Sector " & $info_sector & " down " & $fueldifference & "% in fuel."
				elseif ($spanky = 2)
					setVar $change_port[$used_port_count] "Sector " & $info_sector & " down " & $orgsdifference & "% in orgs."
				elseif ($spanky = 4)
					setVar $change_port[$used_port_count] "Sector " & $info_sector & " down " & $equidifference & "% in equipment."
				elseif ($spanky = 3)
					setVar $change_port[$used_port_count] "Sector " & $info_sector & " down " & $fueldifference & "% in fuel and " & $orgsdifference & "% in orgs."
				elseif ($spanky = 5)
					setVar $change_port[$used_port_count] "Sector " & $info_sector & " down " & $fueldifference & "% in fuel and " & $equidifference & "% in equipment."
				elseif ($spanky = 6)
					setVar $change_port[$used_port_count] "Sector " & $info_sector & " down " & $orgsdifference & "% in orgs and " & $equidifference & "% in equipment."
				elseif ($spanky = 7)
					setVar $change_port[$used_port_count] "Sector " & $info_sector & " down " & $fueldifference & "% in fuel, "  & $orgsdifference & "% in orgs, " & $equidifference & "% in equipment."
				end
			end
			setVar $last_added $info_sector
			add $cim_file_place 1
			goto :cim
		elseif ($cim_info_sector > $info_sector)
			setVar $last_added $info_sector
			add $cim_file_place 1
			goto :cim
		elseif ($cim_info_sector < $info_sector)
			add $used_port_count 1
			add $cim_file_place 1
			setVar $change_port[$used_port_count] "Sector " & $cim_info_sector & " is no longer responding."
			goto :read_file
		end
				
				
			
	
:done
 	killtrigger done
 	killtrigger cim
 	if ($new_file = 1)
		setVar $new_file 0
        else
		delete $cim_file
		rename $cim_temp $cim_file
		delete $cim_temp
	end
	setVar $print_loop 0
	waitfor "(?="
 	if ($used_port_count > 0)
		send "'*"
:print_results
		if ($print_loop	< $used_port_count)
			add $print_loop 1
			send $change_port[$print_loop] "*"
			write $log_file $change_port[$print_loop]
			goto :print_results
		else
			send "*"
		end
	end
return

#Scan Sub =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
:scanme
setVar $newlocation 0
gosub :reset_triggers
waitfor "(?="
setvar $liner 1
cutText CURRENTLINE $location 1 7
striptext $location " "
if ($location = "Command")
	send "d"
elseif ($location = "Citadel") 
	send "s"
else
	send "'Invalid Prompt, could not scan.*"
	return
end
settextlinetrigger scan :scan "<Scan Sector>"
settextlinetrigger scan2 :scan "<Re-Display>"
pause

:scan
gosub :reset_triggers
if ($newlocation = "Warps")
	goto :messageit 
else 
	settextlinetrigger scanner :scanner
	pause
end

:scanner
if (CURRENTLINE <> "")
	setvar $sline[$liner] CURRENTLINE
	cutText CURRENTLINE $newlocation 1 5
	striptext $newlocation " "
	add $liner 1 
end  
goto :scan  

:messageit
setvar $linecount 1
setvar $linecounter 1
send "'*"

:linecount
if ($linecount < $liner) and ($linecounter < 20)
	send $sline[$linecount] "*"
	add $linecount 1
	add $linecounter 1
	goto :linecount
elseif ($linecounter >= 20)
	send "*"
	send "'*"
	send $sline[$linecount] "*"
	add $linecount 1
	setvar $linecounter 1 
	goto :linecount
else      
	send "*"
end
return

#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
:online_watch
killtrigger got_command
killtrigger own_command
setVar $num_new_list 0
setVar $blank 0
waitfor "Who's Playing"
:whos_online
setTextLineTrigger get_names :name_grabber
pause

:name_grabber
setVar $whos_online_ansi CURRENTANSILINE
setVar $whos_online CURRENTLINE
if ($whos_online = "")
	add $blank 1
	if ($blank > 1)
		goto :got_names
	end
else
	add $num_new_list 1
	setVar $ranked_trader $whos_online
	gosub :striprank
	if ($init = 1)
		setVar $old_List[$num_new_list] $rstripped_trader
	else
		setVar $new_List[$num_new_list] $rstripped_trader
	end
end
goto :whos_online

:got_names
if ($init = 1)
	setVar $init 0
	setVar $num_old_list $num_new_list
	goto :wait_for_command
end

:departed_Traders
setVar $departed_Trader_count 0
setVar $departed_loop 0
:departed_loop
if ($departed_loop < $num_old_list)
	add $departed_loop 1
	setVar $departed_inside_loop 0
:departed_inside_loop
	if ($departed_inside_loop < $num_new_list)
		add $departed_inside_loop 1
		if ($old_list[$departed_loop] = $new_list[$departed_inside_loop])
			goto :departed_loop
		else
			goto :departed_inside_loop
		end
	else
		add $departed_Trader_count 1
		setVar $departed_Trader[$departed_trader_count] $old_list[$departed_loop]
		goto :departed_loop
	end
end

:arrived_Traders
setVar $arrived_Trader_count 0
setVar $arrived_loop 0
:arrived_loop
if ($arrived_loop < $num_new_list)
	add $arrived_loop 1
	setVar $arrived_inside_loop 0
:arrived_inside_loop
	if ($arrived_inside_loop < $num_old_list)
		add $arrived_inside_loop 1
		if ($new_List[$arrived_loop] = $old_List[$arrived_inside_loop])
			goto :arrived_loop
		else
			goto :arrived_inside_loop
		end
	else
		add $arrived_Trader_count 1
		setVar $arrived_Trader[$arrived_Trader_count] $new_List[$arrived_loop]
		goto :arrived_loop
	end
end
setVar $new_old 0
:make_new_old
if ($new_old < $num_new_list)
	add $new_old 1
	setVar $old_List[$new_old] $new_List[$new_old]
	goto :make_new_old
end
setVar $num_old_list $num_new_list

:print_list
if ($departed_Trader_count > 0)
	setVar $print_depart 0
	send "'*SupGBot: Departed Player[s]*"
:print_departed
	if ($print_depart < $departed_Trader_count)
		add $print_depart 1
		send " " $departed_Trader[$print_depart] "*"
		goto :print_departed
	else
		send "*"
	end
end
if ($arrived_Trader_count > 0)
	setVar $print_arrived 0
	send "'*SupGBot: New Player[s]*"
:print_arrived
	if ($print_arrived < $arrived_Trader_count)
		add $print_arrived 1
		send " " $arrived_Trader[$print_arrived] "*"
		goto :print_arrived
	else
		send "*"
	end
end
goto :wait_for_command

:striprank
cutText $whos_online_ansi $bor 1 8
cutText $whos_online_ansi $bor1 1 5
cutText $whos_online_ansi $bor2 1 7
if ($bor = "[0m[1;")
	getText $whos_online_ansi $rank "[0m[1;31m" "[36m"
	setVar $rstripped_trader CURRENTLINE
	striptext $rstripped_trader $rank
elseif ($bor = "[0m[32")
	getText $whos_online_ansi $rank "[0m[32m" "[1;36m"
	setVar $rstripped_trader CURRENTLINE
	striptext $rstripped_trader $rank
elseif ($bor = "[1;34mA")
	getText $whos_online_ansi $rank "[1;34m" "[36m"
	setVar $rstripped_trader CURRENTLINE
	striptext $rstripped_trader $rank
elseif ($bor1 = "[32m")
	getText $whos_online_ansi $rank "[32m" "[1;36"
	setVar $rstripped_trader CURRENTLINE
	striptext $rstripped_trader $rank
elseif ($bor2 = "[1;31m")	
	getText $whos_online_ansi $rank "[1;31m" "[36m"
	setVar $rstripped_trader CURRENTLINE
	striptext $rstripped_trader $rank
end
return


:page
sound "message.wav"
sound "message.wav"
sound "message.wav"
send "'Bot Owner has been paged.*"
return

#List of Commands =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
:command_list
waitfor "(?="
send "'* -=-=-=-Available commands for " $user_name "=-=-=-=-*"
send "BLAST - blast off of current planet*"
send "LAND <PLANETNUMBER> - lands on specified planet*"
send "FIRE <SECTOR> - photons specified sector*"
send "PW <SECTOR> - warps planet to specified sector*"
send "SCAN - scans current sector and reports on SS*"
send "WATCH <ON/OFF> - enables photon watch of adj sectors*"
send "STATUS - view the status of the bot*"
if ($user_sec_level > 5)
	send "CIM -  enables cim hunter*"
end
if ($user_sec_level = 9)
	send "adduser <usernamenospcs> <seclevel> adds user with given security level*"
end
send "PAGE - Pages user to keys. (Makes noise on users CPU.)*"
send "KILL - Stops the bot script, for use in emergencies.*"
send "*"
return

#Trigger Reset Sub =-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=
:reset_triggers
killtrigger bjump
killtrigger jump_success
killtrigger in_sector_already
killtrigger limpet
killtrigger no_fuel
killtrigger fighter
killtrigger got_command
killtrigger own_command
killtrigger no_torps
killtrigger have_torps
killtrigger ptorp_fired
killtrigger ptorp_not_adj
killtrigger contstat
killtrigger stattorps
killtrigger got_torps
killtrigger not_here
killtrigger landing
killtrigger in_cit
killtrigger no_cit
killtrigger scanme
killtrigger scan
killtrigger scan2 
return