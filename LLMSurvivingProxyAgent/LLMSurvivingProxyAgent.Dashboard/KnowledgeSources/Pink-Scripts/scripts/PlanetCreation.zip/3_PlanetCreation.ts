# Author          : Alexio
# Script Name     : Planet Creation v2.0
# Last Modified   : 09/5/2002
# Description     : Launches Genesis torpedoes and subsequently 
#                 : destroys the planet until the desired planet
#                 : is created. Will stop if out of either torpedoes 
#                 : or Atomic detenators. Warning be careful of
#                 : experience and alignment if playing blue.
# Updates         : All of it
# Downloaded From : www.geocities.com/alexio_scripts/

CutText CURRENTLINE $Location 1 12
IF ($Location <> "Command [TL=")
     ECHO ANSI_12 "Script Ended: " ANSI_7 "This script must be run from the command prompt"
     goto :End
END

SetVar $Script_Name_Menu "No"
SetVar $Blow_Planet_Menu "No"
SetVar $Save_Setting "No"
SetVar $Count 1

SEND "cn"
WaitFor "(2) Animation display"
GetWord CURRENTLINE $Ansi_Off 5
IF ($Ansi_Off = "On")
     SEND "2qq"
ELSE
     SEND "qq"
END

FileExists $Exist planetlist.txt
IF ($Exist = "FALSE")
     SetVar $Planet_Type "Update Planet List"
ELSE
     READ planetlist.txt $Planet_Type 1
     ADD $Count 1  
END

Logging Off
WaitFor "Command [TL="

:Menu
ECHO ANSI_15 "**     Alexio's Planet Creation Script v2.0*"
ECHO ANSI_8 "----------------------------------------------*"
ECHO ANSI_15 "1 - " ANSI_8 "Planet Type : " ANSI_12 $Planet_Type "*"
ECHO ANSI_15 "2 - " ANSI_8 "Want Script to Name Planet   : " ANSI_10 $Script_Name_Menu "*"
ECHO ANSI_15 "3 - " ANSI_8 "Start by Detonating a Planet : " ANSI_10 $Blow_Planet_Menu "*"
ECHO ANSI_8 "----------------------------------------------"
ECHO ANSI_15 "*C - Continue  U - Update Planet List  Q - Quit*"
GetConsoleInput $Choice SINGLEKEY

:Reset
IF ($Choice = 1) and ($Count = $Count)
     READ planetlist.txt $Planet_Type $Count
     IF ($Planet_Type = "EOF")
          SetVar $Count 1
           goto :Reset
     END
ADD $Count 1
END

IF ($Choice = 2) and ($Script_Name_Menu = "No")
     SetVar $Script_Name_Menu "Yes"
     SetVar $Script_Name "Y"
ELSEIF ($Choice = 2) and ($Script_Name_Menu = "Yes")
         SetVar $Script_Name_Menu "No"
         SetVar $Script_Name "N"
END

IF ($Choice = 3) and ($Blow_Planet_Menu = "No")
     getInput $Planet_Number "Enter Planet Number :"
     SetVar $Blow_Planet_Menu "Yes, #" & $Planet_Number 
     SetVar $Blow_Planet "Y"
ELSEIF ($Choice = 3) and ($Blow_Planet_Menu = "Yes")
      SetVar $Blow_Planet_Menu "No"
      SetVar $Blow_Planet "N"
END

IF ($Choice = "C") 
     IF ($Blow_Planet = "Y")
          goto :Blow_Planet
     ELSE
          goto :Start_Script
     END
ELSEIF ($Choice = "U")
     goto :Update_List
ELSEIF ($Choice = "Q")
     goto :End
END
goto :Menu

:Blow_Planet
KillTrigger stop
KillTrigger go
SEND "l" $Planet_Number "*zdy"
SetTextTrigger stop  :No_Atomic "You do not have any Atomic Detonators!"    
SetTextTrigger go :Start_Script "Command [TL="
pause

:Start_Script
KillTrigger 1
KillTrigger 2
SEND "u"
SetTextTrigger 1 :Gen_Torp "You don't have any Genesis Torpedoes to launch!"
SetTextTrigger 2 :Got_Torp "Do you wish to launch one (Y/N)"
pause

:Got_Torp
SEND "y"
KillTrigger 1
SetTextLineTrigger 1 :Check_Type "What do you want to name this planet?"
pause

:Check_Type
SetVar $Planet_Name CURRENTLINE
GetText CURRENTLINE $Check_Type ", " ")"
StripText $Planet_Name "What do you want to name this planet? "

IF ($Check_Type = $Planet_Type)
     goto :Match
END      

KillTrigger corp
KillTrigger nocorp
SEND ".*l"
SetTextTrigger corp :Corp "Should this be a (C)orporate planet"
SetTextTrigger nocorp :Land "<Preparing ship to land on planet surface>"
pause

:Corp 
KillTrigger nocorp
SEND "cl"

:Land
IF ($Blow_Planet = "Y")
     KillTrigger 1  
     KillTrigger 2
     SEND $Planet_Number "*zdy"
     setTextTrigger 1 :No_Atomic "You do not have any Atomic Detonators!"    
     setTextTrigger 2 :Start_Script "Command [TL="
     pause
END 

:Loop
KillTrigger 1
KillTrigger 2
SetTextTrigger 1 :Blow_Number "   <"
SetTextTrigger 2 :Got_Number "Land on which planet"
pause

:Blow_Number
ADD $P 1
CutText CURRENTLINE $Planet_Num 4 5
StripText $Planet_Num " "
stripText $Planet_Num "<"
stripText $Planet_Num ">"
SetVar $Blow_Number[$P] $Planet_Num
goto :Loop

:Got_Number
KillTrigger 1
KillTrigger 2
SEND $Blow_Number[$P] "*zdy"
SetTextTrigger 1 :No_Atomic "You do not have any Atomic Detonators!"    
SetTextTrigger 2 :Start_Script "Command [TL="
pause  

:Match
ECHO ANSI_10 "   <<<<< Desired Planet Created. >>>>>"
SOUND alert.wav

IF ($Script_Name = "Y")
     SEND $Planet_Name "*"
END
goto :End

:Gen_Torp
KillAllTriggers
WaitFor "Command [TL="
ECHO ANSI_12 "**Script Ended: " ANSI_7 "Out of Genesis Torpedoes!"
goto :End

:No_Atomic 
KillAllTriggers
SEND "qq"
WaitFor "Command [TL="
ECHO ANSI_12 "**Script Ended: " ANSI_7 "Out of Atmoic Detonators!"
goto :End

:Update_List
DELETE planetlist.txt
SetVar $M 1
SetVar $W 0

SEND "cj?"
:Grab_Letters
KillTrigger 1
KillTrigger 2
SetTextLineTrigger 1 :Get_Name "> Class"
SetTextTrigger 2 :Grab_Names "<Q> To Leave"
pause

:Get_Name
ADD $W 1
SetVar $Name[$W] CURRENTLINE
GetWord $Name[$W] $Letter[$W] 1
StripText $Letter[$W] "<"
StripText $Letter[$W] ">"
goto :Grab_Letters

:Grab_Names
SEND $Letter[$M]
WaitFor "Planet Category"
SetVar $Planet_Name[$M] CURRENTLINE
GetWord $Planet_Name[$M] $Stript_It1 6
GetText $Planet_Name[$M] $Stript_It2 "Category " $Stript_It1
StripText $Planet_Name[$M] "Planet Category "
StripText $Planet_Name[$M] $Stript_It2
Write Planetlist.txt $Planet_Name[$M]
WaitFor "Which planet type are you interested in"
IF ($M = $W)
     READ planetlist.txt $Planet_Type 1 
     goto :List_Complete
ELSE
     ADD $M 1
     goto :Grab_Names 
END

:List_Complete
SEND "qq"
WaitFor "Command [TL="
goto :menu

:End
