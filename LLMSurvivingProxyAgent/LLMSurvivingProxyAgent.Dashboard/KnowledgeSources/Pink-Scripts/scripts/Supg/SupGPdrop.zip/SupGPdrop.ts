# Pdrop Script
# Drops a planet on someone stupid enough to hit one of your figs
# Start Script from citadel of the planet you wanna use.

# now we wait
:wait
killtrigger limpettrip
killtrigger trip
killtrigger keepalive
setTextLineTrigger limpettrip :triplimpet "Limpet mine in"
setTextLineTrigger trip :launch "Deployed Fighters Report Sector"
setTextLineTrigger keepalive :keepalive "INACTIVITY WARNING:"
pause


# see if sector limpet is adjacent
:triplimpet
  killtrigger trip
  setVar $line CURRENTLINE
  getword $line $sectorNum 4
  getWord CURRENTLINE $fed 1
  if ($fed = "F")
	goto :wait
  end  
  striptext $sectornum "^"
  stripText $sectorNum " "
  stripText $sectorNum ":"
 
 
goto :warp

# see if sector fig is adjacent
:launch
setVar $line CURRENTLINE
getWord $line $sectorNum 5
striptext $sectornum "^"
stripText $sectorNum " "
stripText $sectorNum ":"

goto :warp



:warp
# place reaction commands here
send "p" $sectorNum "*y"
sound message.wav
goto :wait
halt

#prevent from timeout
:keepalive
  send "#"
  goto :wait
